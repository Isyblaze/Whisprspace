# WhisprSpace safety model (Phase 3)

**Stored (server memory only, expires, lost on restart):** anonymous device IDs (hash of a random key),
report strikes (24h), temporary bans (2h -> 24h -> 7d -> 30d), block pairs (6h).
**Never stored:** audio, names, phone numbers, accounts, IP addresses (only live connection counts).

- Anonymous identity: random Ed25519 key per install; server checks a signed challenge on every connection.
- Report: only valid against the person you were just matched with (during or up to 2 min after the call).
  3 weighted distinct reporters in 24h -> ban. Severe categories (sexual content, hate/threats, underage) count double.
- Block: neither side is matched with the other again for 6 hours. Reporting also blocks.
- Limits: 10 searches/min per device, 150 messages/10s per connection, 8 live connections per IP.
- Not yet built: Play Integrity attestation, audio evidence on report, persistent bans (needs Redis), real age assurance.
