#!/usr/bin/env node
/**
 * WhisprSpace ambient background v2 — 20s seamless loop, "the void".
 * Pure-JS renderer (signed-distance silhouettes + light) piped into ffmpeg.
 *
 *   node tools/render_bg.js [out.mp4]          full render
 *   node tools/render_bg.js --still=7.5 a.png   one frame
 *
 * Faceless figures walk, run, sit and whisper in a violet haze.
 * Every motion completes whole cycles in 20s, so the loop has no seam.
 */
const { spawn } = require('child_process');

const W = 540, H = 960, FPS = 30, DUR = 20, N = FPS * DUR;
const TAU = Math.PI * 2, ASPECT = W / H, CX = ASPECT / 2;
const stillArg = process.argv.find((a) => a.startsWith('--still='));
const STILL = stillArg ? parseFloat(stillArg.split('=')[1]) : null;
const OUT = process.argv.slice(2).find((a) => !a.startsWith('--')) || 'bg_loop.mp4';

const frac = (v) => v - Math.floor(v);
const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);
const smooth = (a, b, v) => { const t = clamp01((v - a) / (b - a)); return t * t * (3 - 2 * t); };
const lerp = (a, b, t) => a + (b - a) * t;
function rng(seed) { return () => { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const rand = rng(23);

// ---- black-currant palette ----
const BG = [5, 3, 12], GLOW = [18, 9, 38];
const VIOLET = [96, 62, 205], INDIGO = [56, 34, 150], BLUE = [34, 70, 200], PLUM = [112, 38, 122], LAV = [150, 122, 235];
const HAZE = [74, 42, 134];
const FAR_COL = [10, 6, 22], NEAR_COL = [3, 2, 8];

// ---- static layer ----
const base = new Float32Array(W * H * 3), dither = new Float32Array(W * H);
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  const X = x / H, Y = y / H, i = y * W + x;
  const g = Math.exp(-((X - CX) ** 2 + (Y - 0.42) ** 2) / 0.11);
  const vx = (x / W - 0.5) * 2, vy = (y / H - 0.5) * 2;
  const vig = 1 - 0.62 * Math.min(1, (vx * vx * 0.6 + vy * vy * 0.9) / 1.3);
  for (let c = 0; c < 3; c++) base[i * 3 + c] = (BG[c] + (GLOW[c] - BG[c]) * g) * vig;
  let h = Math.imul(x * 374761393 + y * 668265263, 1274126177); h = (h ^ (h >>> 13)) >>> 0;
  dither[i] = (h / 4294967296 - 0.5) * 3.0;
}

// ---- figure rig (unit height 1, x forward, y up) ----
class Fig {
  constructor(o) { Object.assign(this, o); this.caps = []; }
  cap(ax, ay, bx, by, ra, rb) {
    const h = this.h, d = this.dir;
    this.caps.push(this.ox + d * ax * h, this.gy - ay * h, this.ox + d * bx * h, this.gy - by * h, ra * h, rb * h);
  }
  pt(lx, ly) { return [this.ox + this.dir * lx * this.h, this.gy - ly * this.h]; }
}
const S = Math.sin, Cs = Math.cos;
function limb(F, x, y, ang, len, ra, rb) {
  const ex = x + len * S(ang), ey = y - len * Cs(ang);
  F.cap(x, y, ex, ey, ra, rb);
  return [ex, ey];
}
function upper(F, hip, lean, tilt) {
  const sx = hip[0] + 0.30 * S(lean), sy = hip[1] + 0.30 * Cs(lean);
  F.cap(hip[0], hip[1], sx, sy, 0.074, 0.084);
  F.cap(sx, sy, sx + 0.05 * S(lean + tilt), sy + 0.05 * Cs(lean + tilt), 0.03, 0.028);
  const hx = sx + 0.118 * S(lean + tilt), hy = sy + 0.118 * Cs(lean + tilt);
  F.cap(hx, hy, hx, hy, 0.062, 0.062);
  F.head = F.pt(hx, hy);
  F.mouth = F.pt(hx + 0.055, hy - 0.025);
  return [sx, sy];
}
function arms(F, sh, a1, b1, a2, b2) {
  const s = [sh[0], sh[1] - 0.02];
  for (const [a, b] of [[a1, b1], [a2, b2]]) {
    const e = limb(F, s[0], s[1], a, 0.17, 0.033, 0.027);
    const w = limb(F, e[0], e[1], a + b, 0.16, 0.026, 0.02);
    F.cap(w[0], w[1], w[0], w[1], 0.024, 0.024);
  }
}
function gait(F, ph, run) {
  const A = run ? 0.78 : 0.40, KF = run ? 1.55 : 0.95, lean = run ? 0.30 : 0.06, armA = run ? 0.9 : 0.5, elb = run ? 1.45 : 0.3;
  const hip = [0, 0.52], legs = []; let minY = 1e9;
  for (const off of [0, Math.PI]) {
    const p = ph + off, a = A * S(p), b = 0.08 + KF * Math.pow(Math.max(0, Cs(p - 0.3)), 1.4);
    const kx = hip[0] + 0.25 * S(a), ky = hip[1] - 0.25 * Cs(a), sa = a - b;
    const ax = kx + 0.24 * S(sa), ay = ky - 0.24 * Cs(sa), f = sa * 0.5;
    const tx = ax + 0.10 * Cs(f), ty = ay + 0.10 * S(f);
    legs.push([kx, ky, ax, ay, tx, ty]);
    minY = Math.min(minY, ay - 0.035, ty - 0.02);
  }
  const dy = -minY; hip[1] += dy;
  for (const L of legs) {
    F.cap(hip[0], hip[1], L[0], L[1] + dy, 0.052, 0.036);
    F.cap(L[0], L[1] + dy, L[2], L[3] + dy, 0.034, 0.022);
    F.cap(L[2], L[3] + dy, L[4], L[5] + dy, 0.024, 0.016);
  }
  const sh = upper(F, hip, lean, 0.05);
  arms(F, sh, armA * S(ph + Math.PI), elb + 0.3 * (0.5 + 0.5 * S(ph + Math.PI)), armA * S(ph), elb + 0.3 * (0.5 + 0.5 * S(ph)));
}
function stand(F, o) {
  const hip = [0, 0.52], sw = o.sway || 0;
  const legs = [[0.05 + sw, 0.0], [-0.05 - sw * 0.5, 0.0]]; let minY = 1e9; const pts = [];
  for (const [a] of legs) {
    const kx = 0.25 * S(a), ky = 0.52 - 0.25 * Cs(a), sa = a - 0.04;
    const ax = kx + 0.24 * S(sa), ay = ky - 0.24 * Cs(sa);
    pts.push([kx, ky, ax, ay, ax + 0.10, ay]); minY = Math.min(minY, ay - 0.035);
  }
  const dy = -minY; hip[1] += dy;
  for (const L of pts) {
    F.cap(0, hip[1], L[0], L[1] + dy, 0.052, 0.036);
    F.cap(L[0], L[1] + dy, L[2], L[3] + dy, 0.034, 0.022);
    F.cap(L[2], L[3] + dy, L[4], L[5] + dy, 0.024, 0.016);
  }
  const sh = upper(F, hip, o.lean, o.tilt || 0);
  const r = o.raise || 0;
  arms(F, sh, lerp(0.12, 0.9, r), lerp(0.25, 2.2, r), 0.06, 0.3);
}
function sit(F, o) {
  const seat = 0.265, hip = [0, seat + 0.04];
  F.cap(-0.34, seat - 0.012, 0.66, seat - 0.012, 0.013, 0.013);
  F.cap(-0.28, seat - 0.012, -0.28, 0, 0.009, 0.009);
  F.cap(0.58, seat - 0.012, 0.58, 0, 0.009, 0.009);
  F.cap(0, hip[1], 0.25, seat + 0.05, 0.056, 0.04);
  F.cap(0.25, seat + 0.05, 0.27, 0.045, 0.036, 0.024);
  F.cap(0.27, 0.045, 0.37, 0.03, 0.024, 0.016);
  F.cap(0, hip[1], 0.28, seat + 0.035, 0.05, 0.036);
  F.cap(0.28, seat + 0.035, 0.31, 0.045, 0.032, 0.022);
  const sh = upper(F, hip, o.lean, o.tilt || 0);
  arms(F, sh, o.a1, o.b1, o.a1 * 0.7, o.b1 * 0.9);
}

// ---- cast ----
const WALK_SPAN = ASPECT + 0.3, X0 = -0.15, X1 = ASPECT + 0.15;
const walker = (o) => { const n = Math.round(WALK_SPAN / (0.86 * o.h)); return { ...o, n, kind: 'walk' }; };
const figs = [], pairs = [];
const add = (layer, o) => { const f = new Fig({ layer, ox: 0, head: [0, 0], mouth: [0, 0], ...o }); figs.push(f); return f; };

const FARY = 0.575, MIDY = 0.69;
// far layer
add(0, { h: 0.085, gy: FARY, dir: 1, ...walker({ h: 0.085, off: 0.15, p0: 0.3 }) });
add(0, { h: 0.085, gy: FARY, dir: -1, kind: 'run', a: 12, D: 5, m: 6, p0: 1.0 });
add(0, { h: 0.085, gy: FARY, dir: 1, kind: 'sit', lean: 0.22, tilt: 0.28, a1: 0.5, b1: 1.7, ox: 0.41, ph: 0.9 });
{ const A = add(0, { h: 0.085, gy: FARY, dir: 1, kind: 'stand', ox: 0.15, ph: 0.0, role: 'whisperer' });
  const B = add(0, { h: 0.085, gy: FARY, dir: -1, kind: 'stand', ox: 0.15 + 0.37 * 0.085, ph: 2.1, role: 'listener' });
  pairs.push({ A, B, k: 2, p: 0.0 }); }
// mid layer
add(1, { h: 0.14, gy: MIDY, dir: -1, ...walker({ h: 0.14, off: 0.62, p0: 1.4 }) });
add(1, { h: 0.15, gy: MIDY, dir: 1, ...walker({ h: 0.15, off: 0.93, p0: 2.6 }) });
add(1, { h: 0.14, gy: MIDY, dir: 1, kind: 'run', a: 3, D: 5, m: 6, p0: 0.2 });
{ const A = add(1, { h: 0.14, gy: MIDY, dir: 1, kind: 'sitw', ox: 0.14, ph: 0.4, role: 'whisperer' });
  const B = add(1, { h: 0.14, gy: MIDY, dir: 1, kind: 'sitl', ox: 0.14 + 0.31 * 0.14, ph: 1.7, role: 'listener' });
  pairs.push({ A, B, k: 2, p: 0.5 }); }

function bump(pr, u) { return smooth(0.18, 0.82, 0.5 - 0.5 * Cs(TAU * (pr.k * u + pr.p))); }

function build(F, t, u) {
  F.caps.length = 0; F.vis = 1;
  const pair = pairs.find((p) => p.A === F || p.B === F);
  const bp = pair ? bump(pair, u) : 0;
  if (F.kind === 'walk') {
    const s = frac(u + F.off);
    F.ox = F.dir > 0 ? X0 + WALK_SPAN * s : X1 - WALK_SPAN * s;
    gait(F, TAU * F.n * (u + F.off) + F.p0, false);
  } else if (F.kind === 'run') {
    const s = (t - F.a) / F.D;
    if (s < 0 || s > 1) { F.vis = 0; return; }
    F.ox = F.dir > 0 ? X0 + WALK_SPAN * s : X1 - WALK_SPAN * s;
    gait(F, TAU * F.m * s + F.p0, true);
  } else if (F.kind === 'sit') {
    sit(F, { lean: F.lean + 0.015 * S(TAU * u * 5 + F.ph), tilt: F.tilt, a1: F.a1, b1: F.b1 });
  } else if (F.kind === 'sitw') {
    sit(F, { lean: 0.08 + 0.36 * bp, tilt: -0.1 * bp, a1: 0.2, b1: 1.2 });
  } else if (F.kind === 'sitl') {
    sit(F, { lean: 0.03 + 0.02 * S(TAU * u * 5 + F.ph), tilt: 0.12 * bp, a1: 0.25, b1: 1.3 });
  } else if (F.kind === 'stand') {
    if (F.role === 'whisperer') stand(F, { lean: 0.04 + 0.2 * bp, tilt: 0.0, raise: bp, sway: 0.02 * S(TAU * u * 4 + F.ph) });
    else stand(F, { lean: 0.02, tilt: 0.14 * bp, sway: 0.02 * S(TAU * u * 4 + F.ph) });
  }
}

// ---- buffers ----
const acc = new Float32Array(W * H * 3);
const layerC = [new Float32Array(W * H), new Float32Array(W * H)];
const layerH = [new Float32Array(W * H), new Float32Array(W * H)];
const HW = 0.010;

function raster(F, C, Hh, soft, alpha, hamp) {
  const c = F.caps, nC = c.length / 6; if (!nC) return;
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (let k = 0; k < nC; k++) {
    const j = k * 6, r = Math.max(c[j + 4], c[j + 5]);
    x0 = Math.min(x0, c[j] - r, c[j + 2] - r); x1 = Math.max(x1, c[j] + r, c[j + 2] + r);
    y0 = Math.min(y0, c[j + 1] - r, c[j + 3] - r); y1 = Math.max(y1, c[j + 1] + r, c[j + 3] + r);
  }
  const m = soft + 3 * HW;
  const px0 = Math.max(0, Math.floor((x0 - m) * H)), px1 = Math.min(W - 1, Math.ceil((x1 + m) * H));
  const py0 = Math.max(0, Math.floor((y0 - m) * H)), py1 = Math.min(H - 1, Math.ceil((y1 + m) * H));
  if (px1 < px0 || py1 < py0) return;
  const ab = new Float64Array(nC * 3);
  for (let k = 0; k < nC; k++) { const j = k * 6, dx = c[j + 2] - c[j], dy = c[j + 3] - c[j + 1], l2 = dx * dx + dy * dy; ab[k * 3] = dx; ab[k * 3 + 1] = dy; ab[k * 3 + 2] = l2 > 1e-10 ? 1 / l2 : 0; }
  for (let py = py0; py <= py1; py++) {
    const Y = (py + 0.5) / H;
    for (let px = px0; px <= px1; px++) {
      const X = (px + 0.5) / H; let d = 1e9;
      for (let k = 0; k < nC; k++) {
        const j = k * 6, ax = c[j], ay = c[j + 1];
        let t = ((X - ax) * ab[k * 3] + (Y - ay) * ab[k * 3 + 1]) * ab[k * 3 + 2]; t = t < 0 ? 0 : t > 1 ? 1 : t;
        const ex = ax + ab[k * 3] * t - X, ey = ay + ab[k * 3 + 1] * t - Y;
        const dd = Math.sqrt(ex * ex + ey * ey) - (c[j + 4] + (c[j + 5] - c[j + 4]) * t);
        if (dd < d) d = dd;
      }
      const i = py * W + px;
      if (d < soft) {
        const cv = d < -soft ? 1 : 1 - smooth(-soft, soft, d);
        const v = cv * alpha; if (v > C[i]) C[i] = v;
      }
      if (d > -soft && d < 3 * HW) { const hv = Math.exp(-Math.max(d, 0) / HW) * hamp * alpha; if (hv > Hh[i]) Hh[i] = hv; }
    }
  }
}

function addSpot(cx, cy, rad, s2, r, g, b, a) {
  const px0 = Math.max(0, Math.floor((cx - rad) * H)), px1 = Math.min(W - 1, Math.ceil((cx + rad) * H));
  const py0 = Math.max(0, Math.floor((cy - rad) * H)), py1 = Math.min(H - 1, Math.ceil((cy + rad) * H));
  for (let py = py0; py <= py1; py++) for (let px = px0; px <= px1; px++) {
    const dx = (px + 0.5) / H - cx, dy = (py + 0.5) / H - cy, v = Math.exp(-(dx * dx + dy * dy) / s2) * a, o = (py * W + px) * 3;
    acc[o] += r * v; acc[o + 1] += g * v; acc[o + 2] += b * v;
  }
}
function addArc(mx, my, dirx, diry, rad, w, a) {
  const R = rad + w * 4, px0 = Math.max(0, Math.floor((mx - R) * H)), px1 = Math.min(W - 1, Math.ceil((mx + R) * H));
  const py0 = Math.max(0, Math.floor((my - R) * H)), py1 = Math.min(H - 1, Math.ceil((my + R) * H));
  const ang0 = Math.atan2(diry, dirx);
  for (let py = py0; py <= py1; py++) for (let px = px0; px <= px1; px++) {
    const dx = (px + 0.5) / H - mx, dy = (py + 0.5) / H - my, d = Math.sqrt(dx * dx + dy * dy), q = (d - rad) / w;
    if (q < -3 || q > 3) continue;
    let da = Math.atan2(dy, dx) - ang0; da = Math.atan2(Math.sin(da), Math.cos(da));
    const span = Math.exp(-(da * da) / 0.35);
    const v = Math.exp(-q * q) * span * a, o = (py * W + px) * 3;
    acc[o] += LAV[0] * v; acc[o + 1] += LAV[1] * v; acc[o + 2] += LAV[2] * v;
  }
}

// ---- background ingredients ----
const blobs = [
  { x: CX, y: 0.34, ax: 0.20, ay: 0.10, kx: 1, ky: 2, px: 0.0, py: 1.1, r: 0.58, col: VIOLET, a: 0.12 },
  { x: CX, y: 0.60, ax: 0.22, ay: 0.12, kx: 2, ky: 1, px: 2.0, py: 0.4, r: 0.62, col: INDIGO, a: 0.17 },
  { x: CX, y: 0.84, ax: 0.18, ay: 0.06, kx: 1, ky: 1, px: 4.1, py: 2.2, r: 0.55, col: BLUE, a: 0.08 },
  { x: CX, y: 0.50, ax: 0.20, ay: 0.14, kx: 1, ky: 3, px: 1.3, py: 5.0, r: 0.50, col: PLUM, a: 0.10 },
];
const EMIT = { x: CX, y: 0.375 };
const motes = Array.from({ length: 30 }, () => ({
  x: rand() * ASPECT, y: rand(), s: rand() < 0.6 ? 1 : 2, sway: 0.008 + rand() * 0.02, sk: 1 + Math.floor(rand() * 3),
  sp: rand() * TAU, size: 1.1 + rand() * 1.7, b: 0.16 + rand() * 0.26, tk: 1 + Math.floor(rand() * 4), tp: rand() * TAU,
}));
const patchBack = new Float32Array(W), patchFront = new Float32Array(W);

function renderFrame(f, buf) {
  const t = f / FPS, u = t / DUR;
  const gain = 0.88 + 0.12 * Math.sin(TAU * u - 1.2);
  acc.fill(0); for (const a of layerC) a.fill(0); for (const a of layerH) a.fill(0);

  // figures
  for (const F of figs) {
    build(F, t, u); if (!F.vis) continue;
    if (F.layer === 0) raster(F, layerC[0], layerH[0], 0.0045, 0.55, 0.10);
    else raster(F, layerC[1], layerH[1], 0.0026, 0.86, 0.14);
  }
  // whisper arcs
  for (const pr of pairs) {
    const b = bump(pr, u); if (b < 0.05) continue;
    const M = pr.A.mouth, E = pr.B.head, dx = E[0] - M[0], dy = E[1] - M[1], L = Math.hypot(dx, dy) || 1, h = pr.A.h;
    for (let j = 0; j < 3; j++) {
      const ph = frac(u * 10 + j / 3);
      addArc(M[0], M[1], dx / L, dy / L, h * (0.10 + ph * 0.55), h * 0.028, Math.pow(1 - ph, 1.5) * smooth(0, 0.12, ph) * b * 0.55 * gain);
    }
  }
  // dust
  for (const m of motes) {
    const yy = frac(m.y - m.s * u), xx = m.x + m.sway * Math.sin(TAU * m.sk * u + m.sp);
    const al = m.b * Math.pow(Math.sin(Math.PI * yy), 0.8) * (0.6 + 0.4 * Math.sin(TAU * m.tk * u + m.tp)) * gain;
    const s2 = 2 * (m.size / H) * (m.size / H);
    addSpot(xx, yy, m.size * 4 / H, s2, LAV[0] * 0.7, LAV[1] * 0.7, LAV[2] * 0.7, al);
  }
  // haze patches (drift, loop-safe)
  for (let x = 0; x < W; x++) {
    const xn = x / W;
    patchBack[x] = Math.max(0.12, 0.55 + 0.45 * S(TAU * (1.7 * xn - u) + 1.0) * S(TAU * (2.9 * xn + 2 * u) + 0.3));
    patchFront[x] = Math.max(0.10, 0.55 + 0.45 * S(TAU * (2.3 * xn + u) + 2.0) * S(TAU * (1.3 * xn - 2 * u) + 0.9));
  }
  const B = blobs.map((b) => ({
    x: b.x + b.ax * S(TAU * b.kx * u + b.px), y: b.y + b.ay * Cs(TAU * b.ky * u + b.py), r: b.r, r2: b.r * b.r,
    cr: b.col[0] * b.a * gain, cg: b.col[1] * b.a * gain, cb: b.col[2] * b.a * gain,
  }));
  const R = [];
  for (let j = 0; j < 4 && true; j++) {
    const ph = frac(t / 5 - 0.12 * j), amp = Math.pow(1 - ph, 1.7) * smooth(0, 0.07, ph) * (0.24 - 0.06 * j) * gain;
    if (j < 3 && amp > 0.004) R.push({ r: 0.11 + ph * 0.85, w: 0.009 + ph * 0.022, amp });
  }

  for (let y = 0; y < H; y++) {
    const Y = y / H, dyE = Y - EMIT.y;
    const hb = 0.20 * Math.exp(-(((Y - 0.64) / 0.10) ** 2)) * gain, hf = 0.11 * Math.exp(-(((Y - 0.705) / 0.07) ** 2)) * gain;
    const inBand = Y > 0.30;
    for (let x = 0; x < W; x++) {
      const X = x / H, i = y * W + x, o = i * 3, ao = o;
      let r = base[o], g = base[o + 1], b = base[o + 2];
      for (let k = 0; k < B.length; k++) {
        const bl = B[k], dx = X - bl.x, dy = Y - bl.y, d2 = dx * dx + dy * dy;
        if (d2 < bl.r2) { let tt = 1 - d2 / bl.r2; tt *= tt; r += bl.cr * tt; g += bl.cg * tt; b += bl.cb * tt; }
      }
      if (R.length) {
        const dxE = X - EMIT.x, d = Math.sqrt(dxE * dxE + dyE * dyE);
        for (let k = 0; k < R.length; k++) {
          const dd = (d - R[k].r) / R[k].w;
          if (dd > -3 && dd < 3) { const v = Math.exp(-dd * dd) * R[k].amp * 0.55; r += LAV[0] * v; g += LAV[1] * v; b += LAV[2] * v; }
        }
      }
      if (inBand) {
        const v = hb * patchBack[x]; r += HAZE[0] * v; g += HAZE[1] * v; b += HAZE[2] * v;
        const fc = layerC[0][i], fh = layerH[0][i];
        if (fc > 0 || fh > 0) {
          r = r * (1 - fc) + FAR_COL[0] * fc + LAV[0] * fh * 0.35 * (1 - fc);
          g = g * (1 - fc) + FAR_COL[1] * fc + LAV[1] * fh * 0.35 * (1 - fc);
          b = b * (1 - fc) + FAR_COL[2] * fc + LAV[2] * fh * 0.35 * (1 - fc);
        }
        const v2 = hf * patchFront[x]; r += HAZE[0] * v2; g += HAZE[1] * v2; b += HAZE[2] * v2;
        const nc = layerC[1][i], nh = layerH[1][i];
        if (nc > 0 || nh > 0) {
          r = r * (1 - nc) + NEAR_COL[0] * nc + LAV[0] * nh * 0.40 * (1 - nc);
          g = g * (1 - nc) + NEAR_COL[1] * nc + LAV[1] * nh * 0.40 * (1 - nc);
          b = b * (1 - nc) + NEAR_COL[2] * nc + LAV[2] * nh * 0.40 * (1 - nc);
        }
      }
      const dth = dither[i];
      r += acc[ao] + dth; g += acc[ao + 1] + dth; b += acc[ao + 2] + dth;
      buf[o] = r < 0 ? 0 : r > 255 ? 255 : r; buf[o + 1] = g < 0 ? 0 : g > 255 ? 255 : g; buf[o + 2] = b < 0 ? 0 : b > 255 ? 255 : b;
    }
  }
}

async function main() {
  const still = STILL !== null;
  const args = still
    ? ['-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', `${W}x${H}`, '-i', 'pipe:0', '-frames:v', '1', process.argv.slice(2).find((a) => a.endsWith('.png')) || 'still.png']
    : ['-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', `${W}x${H}`, '-r', String(FPS), '-i', 'pipe:0',
      '-vf', 'scale=720:1280:flags=bicubic,format=yuv420p', '-c:v', 'libx264', '-profile:v', 'main', '-preset', 'slow', '-crf', '23', '-g', '90',
      '-x264-params', 'aq-mode=3:deblock=-1,-1', '-movflags', '+faststart', '-an', OUT];
  const ff = spawn('ffmpeg', args, { stdio: ['pipe', 'inherit', 'inherit'] });
  const done = new Promise((res) => ff.on('close', res));
  const t0 = Date.now(), total = still ? 1 : N;
  for (let k = 0; k < total; k++) {
    const buf = Buffer.allocUnsafe(W * H * 3);
    renderFrame(still ? Math.round(STILL * FPS) : k, buf);
    if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
    if (!still && k % 60 === 0) process.stderr.write(`frame ${k}/${total}  ${((Date.now() - t0) / 1000).toFixed(0)}s\n`);
  }
  ff.stdin.end(); await done;
  console.log(still ? 'still done' : `done -> ${OUT}`);
}
main();
