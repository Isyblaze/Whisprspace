#!/usr/bin/env node
/**
 * WhisprSpace ambient background — 15s seamless loop.
 * Pure-JS software renderer piped into ffmpeg. No npm packages needed.
 *
 *   node tools/render_bg.js [out.mp4] [--preview]
 *
 * Every motion uses a whole number of cycles per 15s, so frame 450 == frame 0.
 *
 * Story (one slow breath):
 *   0-5s   drifting aurora, a first whisper ripple leaves the centre
 *   5-10s  second ripple, sound-lines swell, dust rises
 *   10-15s third ripple, everything exhales and returns to the start
 */
const { spawn } = require('child_process');

const W = 540, H = 960, FPS = 30, DUR = 15, N = FPS * DUR;
const TAU = Math.PI * 2;
const ASPECT = W / H;
const OUT = process.argv.find((a, i) => i > 1 && !a.startsWith('--')) || 'bg_loop.mp4';
const PREVIEW = process.argv.includes('--preview'); // render only a few frames
const FRAMES = PREVIEW ? 12 : N;

const frac = (v) => v - Math.floor(v);
const smooth = (a, b, v) => { const t = Math.min(1, Math.max(0, (v - a) / (b - a))); return t * t * (3 - 2 * t); };
function rng(seed) { return () => { seed |= 0; seed = (seed + 0x6D2B79F5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const rand = rng(11);

// ---- palette (from the app icon) ----
const BG = [10, 7, 32];
const GLOW = [22, 15, 58];
const VIOLET = [124, 92, 240];
const INDIGO = [75, 47, 196];
const BLUE = [47, 107, 255];
const LAV = [170, 150, 255];

// ---- static layer: base gradient * vignette, and dither ----
const CX = ASPECT / 2;
const base = new Float32Array(W * H * 3);
const dither = new Float32Array(W * H);
for (let y = 0; y < H; y++) {
  for (let x = 0; x < W; x++) {
    const X = x / H, Y = y / H, i = y * W + x;
    const dx = X - CX, dy = Y - 0.44;
    const g = Math.exp(-(dx * dx + dy * dy) / 0.11);
    const vx = (x / W - 0.5) * 2, vy = (y / H - 0.5) * 2;
    const vig = 1 - 0.5 * Math.min(1, (vx * vx * 0.6 + vy * vy * 0.9) / 1.3);
    for (let c = 0; c < 3; c++) base[i * 3 + c] = (BG[c] + (GLOW[c] - BG[c]) * g) * vig;
    let h = Math.imul(x * 374761393 + y * 668265263, 1274126177); h = (h ^ (h >>> 13)) >>> 0;
    dither[i] = (h / 4294967296 - 0.5) * 3.0; // static, so it costs nothing in the encode
  }
}

// ---- scene definitions ----
const blobs = [
  { x: CX, y: 0.36, ax: 0.20, ay: 0.10, kx: 1, ky: 2, px: 0.0, py: 1.1, r: 0.55, col: VIOLET, a: 0.15 },
  { x: CX, y: 0.62, ax: 0.22, ay: 0.12, kx: 2, ky: 1, px: 2.0, py: 0.4, r: 0.60, col: INDIGO, a: 0.20 },
  { x: CX, y: 0.82, ax: 0.18, ay: 0.06, kx: 1, ky: 1, px: 4.1, py: 2.2, r: 0.55, col: BLUE, a: 0.12 },
  { x: CX, y: 0.18, ax: 0.14, ay: 0.06, kx: 3, ky: 1, px: 1.3, py: 5.0, r: 0.40, col: VIOLET, a: 0.08 },
];
const EMIT = { x: CX, y: 0.46 };
const lines = [
  { off: -0.030, f: 1.4, c: 1, ph: 0.0, a: 0.030, m: 1, mp: 0.0, w: 0.0032, k: 0.17 },
  { off: 0.000, f: 2.1, c: -2, ph: 1.7, a: 0.040, m: 2, mp: 1.9, w: 0.0036, k: 0.21 },
  { off: 0.030, f: 3.0, c: 1, ph: 3.4, a: 0.026, m: 1, mp: 3.8, w: 0.0030, k: 0.14 },
];
const LINE_Y = 0.80;
const motes = Array.from({ length: 38 }, () => ({
  x: rand() * ASPECT, y: rand(), s: rand() < 0.6 ? 1 : 2, sway: 0.008 + rand() * 0.02, sk: 1 + Math.floor(rand() * 3),
  sp: rand() * TAU, size: 1.1 + rand() * 1.9, b: 0.18 + rand() * 0.30, tk: 1 + Math.floor(rand() * 4), tp: rand() * TAU,
}));
const lineY = lines.map(() => new Float32Array(W));

function renderFrame(f, buf) {
  const t = (f / FPS) % DUR, u = t / DUR;
  const gain = 0.86 + 0.14 * Math.sin(TAU * u - 1.2); // one slow breath per loop
  const acc = new Float32Array(W * H * 3); // additive light

  // blobs
  const B = blobs.map((b) => ({
    x: b.x + b.ax * Math.sin(TAU * b.kx * u + b.px), y: b.y + b.ay * Math.cos(TAU * b.ky * u + b.py),
    r2: b.r * b.r, cr: b.col[0] * b.a * gain, cg: b.col[1] * b.a * gain, cb: b.col[2] * b.a * gain, r: b.r,
  }));
  // ripples (period 5s -> 3 per loop)
  const R = [];
  for (let j = 0; j < 3; j++) {
    const ph = frac(t / 5 - 0.12 * j);
    const amp = Math.pow(1 - ph, 1.7) * smooth(0, 0.07, ph) * (0.30 - 0.08 * j) * gain;
    if (amp > 0.004) R.push({ r: 0.11 + ph * 0.85, w: 0.009 + ph * 0.022, amp });
  }
  // sound-lines
  const LA = lines.map((l, li) => {
    const A = l.a * (0.62 + 0.38 * Math.sin(TAU * l.m * u + l.mp)) * (0.8 + 0.2 * Math.sin(TAU * u * 2));
    for (let px = 0; px < W; px++) {
      const uu = px / W, env = Math.sin(Math.PI * uu);
      lineY[li][px] = LINE_Y + l.off + A * env * Math.sin(TAU * (l.f * uu + l.c * u) + l.ph);
    }
    return A;
  });
  const lineBand = 0.09;

  for (let y = 0; y < H; y++) {
    const Y = y / H;
    const nearLines = Math.abs(Y - LINE_Y) < lineBand;
    const dyE = Y - EMIT.y;
    for (let x = 0; x < W; x++) {
      const X = x / H, i = y * W + x, o = i * 3;
      let r = 0, g = 0, b = 0;
      for (let k = 0; k < B.length; k++) {
        const bl = B[k], dx = X - bl.x, dy = Y - bl.y, d2 = dx * dx + dy * dy;
        if (d2 < bl.r2) { let tt = 1 - d2 / bl.r2; tt *= tt; r += bl.cr * tt; g += bl.cg * tt; b += bl.cb * tt; }
      }
      if (R.length) {
        const dxE = X - EMIT.x, d = Math.sqrt(dxE * dxE + dyE * dyE);
        for (let k = 0; k < R.length; k++) {
          const dd = (d - R[k].r) / R[k].w;
          if (dd > -3 && dd < 3) { const v = Math.exp(-dd * dd) * R[k].amp; r += LAV[0] * v * 0.55; g += LAV[1] * v * 0.55; b += LAV[2] * v * 0.55; }
        }
      }
      if (nearLines) {
        const uu = x / W;
        const cr = VIOLET[0] + (BLUE[0] - VIOLET[0]) * uu, cg = VIOLET[1] + (BLUE[1] - VIOLET[1]) * uu, cb = VIOLET[2] + (BLUE[2] - VIOLET[2]) * uu;
        for (let k = 0; k < lines.length; k++) {
          const dy = Y - lineY[k][x];
          if (dy > -0.03 && dy < 0.03) {
            const w = lines[k].w, v = (Math.exp(-(dy / w) * (dy / w)) + 0.16 * Math.exp(-(dy / (w * 6)) * (dy / (w * 6)))) * lines[k].k * gain;
            r += cr * v * 0.8; g += cg * v * 0.8; b += cb * v * 0.8;
          }
        }
      }
      acc[o] = r; acc[o + 1] = g; acc[o + 2] = b;
    }
  }
  // dust motes
  for (const m of motes) {
    const yy = frac(m.y - m.s * u);
    const xx = m.x + m.sway * Math.sin(TAU * m.sk * u + m.sp);
    const al = m.b * Math.pow(Math.sin(Math.PI * yy), 0.8) * (0.6 + 0.4 * Math.sin(TAU * m.tk * u + m.tp)) * gain;
    const cx = xx * H, cy = yy * H, rad = Math.ceil(m.size * 3.5), s2 = 2 * m.size * m.size;
    for (let py = Math.max(0, Math.floor(cy) - rad); py <= Math.min(H - 1, Math.floor(cy) + rad); py++) {
      for (let px = Math.max(0, Math.floor(cx) - rad); px <= Math.min(W - 1, Math.floor(cx) + rad); px++) {
        const v = Math.exp(-((px - cx) ** 2 + (py - cy) ** 2) / s2) * al, o = (py * W + px) * 3;
        acc[o] += LAV[0] * v * 0.7; acc[o + 1] += LAV[1] * v * 0.7; acc[o + 2] += LAV[2] * v * 0.7;
      }
    }
  }
  // compose
  for (let i = 0, n = W * H; i < n; i++) {
    const dth = dither[i];
    for (let c = 0; c < 3; c++) {
      const v = base[i * 3 + c] + acc[i * 3 + c] + dth;
      buf[i * 3 + c] = v < 0 ? 0 : v > 255 ? 255 : v;
    }
  }
}

async function main() {
  const ff = spawn('ffmpeg', [
    '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', `${W}x${H}`, '-r', String(FPS), '-i', 'pipe:0',
    '-vf', 'scale=720:1280:flags=bicubic,format=yuv420p',
    '-c:v', 'libx264', '-profile:v', 'main', '-preset', 'slow', '-crf', '23', '-g', '90',
    '-x264-params', 'aq-mode=3:deblock=-1,-1', '-movflags', '+faststart', '-an', OUT,
  ], { stdio: ['pipe', 'inherit', 'inherit'] });
  const done = new Promise((res) => ff.on('close', res));
  const t0 = Date.now();
  for (let f = 0; f < FRAMES; f++) {
    const buf = Buffer.allocUnsafe(W * H * 3);
    renderFrame(f, buf);
    if (!ff.stdin.write(buf)) await new Promise((r) => ff.stdin.once('drain', r));
    if (f % 30 === 0) process.stderr.write(`frame ${f}/${FRAMES}  ${((Date.now() - t0) / 1000).toFixed(0)}s\n`);
  }
  ff.stdin.end();
  await done;
  console.log(`done -> ${OUT}`);
}
main();
