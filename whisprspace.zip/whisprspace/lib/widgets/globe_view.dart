import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';
import '../services/match_service.dart';

class GlobeController extends ChangeNotifier {
  double lon = 0.35, lat = 0.35, zoom = 1.0;
  double vLon = 0, vLat = 0;
  double lastTouch = -100;
  Region? sel;
  bool searching = false;
  ui.Image? heat;
  void changed() => notifyListeners();
}

/// Interactive 3D Earth drawn on the GPU by shaders/globe.frag.
class GlobeView extends StatefulWidget {
  final GlobeController ctrl;
  final Animation<double> intro;
  final void Function(double latDeg, double lonDeg)? onPick;
  const GlobeView({super.key, required this.ctrl, required this.intro, this.onPick});
  @override
  State<GlobeView> createState() => _GlobeViewState();
}

class _GlobeViewState extends State<GlobeView> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final ValueNotifier<double> _time = ValueNotifier(0);
  ui.FragmentShader? _shader;
  ui.Image? _earth;
  bool _failed = false;
  Duration _last = Duration.zero;
  double _startZoom = 1;
  Size _size = Size.zero;

  GlobeController get c => widget.ctrl;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_tick)..start();
    _load();
  }

  Future<void> _load() async {
    try {
      final prog = await ui.FragmentProgram.fromAsset('shaders/globe.frag');
      final data = await rootBundle.load('assets/earth.jpg');
      final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
      final fi = await codec.getNextFrame();
      if (!mounted) return;
      setState(() {
        _shader = prog.fragmentShader();
        _earth = fi.image;
      });
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  void _tick(Duration d) {
    final t = d.inMicroseconds / 1e6;
    final dt = (d - _last).inMicroseconds / 1e6;
    _last = d;
    if (dt > 0 && dt < 0.2) {
      if (c.vLon.abs() > 1e-4 || c.vLat.abs() > 1e-4) {
        c.lon += c.vLon * dt;
        c.lat = (c.lat + c.vLat * dt).clamp(-1.35, 1.35).toDouble();
        final k = math.exp(-dt * 2.6);
        c.vLon *= k;
        c.vLat *= k;
      } else if (t - c.lastTouch > 3.5) {
        c.lon += (c.searching ? 0.10 : 0.04) * dt;
      }
    }
    _time.value = t;
  }

  double _introScale() => 0.12 + 0.88 * Curves.easeOutCubic.transform(widget.intro.value.clamp(0.0, 1.0));
  double _radius() => math.min(_size.width, _size.height) * 0.43 * c.zoom * _introScale();

  void _pick(Offset p) {
    final R = _radius();
    final x = (p.dx - _size.width / 2) / R, y = -(p.dy - _size.height / 2) / R;
    final r2 = x * x + y * y;
    if (r2 >= 1) return;
    final z = math.sqrt(1 - r2);
    final cl = math.cos(c.lat), sl = math.sin(c.lat), co = math.cos(c.lon), so = math.sin(c.lon);
    final wx = x * co + y * (-sl * so) + z * (cl * so);
    final wy = y * cl + z * sl;
    final wz = x * (-so) + y * (-sl * co) + z * (cl * co);
    widget.onPick?.call(math.asin(wy.clamp(-1.0, 1.0)) * 180 / math.pi, math.atan2(wx, wz) * 180 / math.pi);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _time.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) {
      return const Center(
        child: SizedBox(
          width: 260,
          height: 260,
          child: DecoratedBox(
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(center: Alignment(-0.4, -0.4), colors: [Color(0xFF4B2FC4), Color(0xFF0C0626)]),
            ),
          ),
        ),
      );
    }
    return LayoutBuilder(builder: (ctx, cons) {
      _size = Size(cons.maxWidth, cons.maxHeight);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onScaleStart: (d) {
          _startZoom = c.zoom;
          c.vLon = 0;
          c.vLat = 0;
          c.lastTouch = _time.value;
        },
        onScaleUpdate: (d) {
          final R = _radius();
          final cosLat = math.max(math.cos(c.lat), 0.25);
          c.lon -= d.focalPointDelta.dx / (R * cosLat);
          c.lat = (c.lat + d.focalPointDelta.dy / R).clamp(-1.35, 1.35).toDouble();
          c.zoom = (_startZoom * d.scale).clamp(0.75, 3.2).toDouble();
          c.lastTouch = _time.value;
        },
        onScaleEnd: (d) {
          final R = _radius();
          final v = d.velocity.pixelsPerSecond;
          final cosLat = math.max(math.cos(c.lat), 0.25);
          c.vLon = (-v.dx / (R * cosLat) * 0.6).clamp(-4.0, 4.0).toDouble();
          c.vLat = (v.dy / R * 0.6).clamp(-4.0, 4.0).toDouble();
          c.lastTouch = _time.value;
        },
        onTapUp: (d) => _pick(d.localPosition),
        child: CustomPaint(
          size: Size.infinite,
          painter: _GlobePainter(c, widget.intro, _time, _shader, _earth),
        ),
      );
    });
  }
}

class _GlobePainter extends CustomPainter {
  final GlobeController c;
  final Animation<double> intro;
  final ValueNotifier<double> time;
  final ui.FragmentShader? sh;
  final ui.Image? earth;
  _GlobePainter(this.c, this.intro, this.time, this.sh, this.earth) : super(repaint: Listenable.merge([c, intro, time]));

  @override
  void paint(Canvas canvas, Size size) {
    final heat = c.heat;
    final s = sh;
    if (s == null || earth == null || heat == null) return;
    final k = 0.12 + 0.88 * Curves.easeOutCubic.transform(intro.value.clamp(0.0, 1.0));
    final R = math.min(size.width, size.height) * 0.43 * c.zoom * k;
    final sel = c.sel;
    s.setFloat(0, size.width);
    s.setFloat(1, size.height);
    s.setFloat(2, c.lon);
    s.setFloat(3, c.lat);
    s.setFloat(4, R);
    s.setFloat(5, time.value);
    s.setFloat(6, sel == null ? 0 : sel.lat * math.pi / 180);
    s.setFloat(7, sel == null ? 0 : sel.lon * math.pi / 180);
    s.setFloat(8, sel == null ? 0 : sel.km / 6371.0);
    s.setFloat(9, 1.0);
    s.setFloat(10, c.searching ? 1.0 : 0.0);
    s.setImageSampler(0, earth!);
    s.setImageSampler(1, heat);
    canvas.drawRect(Offset.zero & size, Paint()..shader = s);
  }

  @override
  bool shouldRepaint(_GlobePainter old) => old.sh != sh || old.earth != earth;
}
