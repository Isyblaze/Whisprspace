import 'dart:math';
import 'package:flutter/material.dart';
import '../theme.dart';

class Orb extends StatelessWidget {
  final Animation<double> t;
  final double intensity;
  final double size;
  const Orb({super.key, required this.t, this.intensity = 0.3, this.size = 280});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: t,
        builder: (_, __) => CustomPaint(
          size: Size.square(size),
          painter: _OrbPainter(t.value, intensity),
        ),
      );
}

class _OrbPainter extends CustomPainter {
  final double t, k;
  _OrbPainter(this.t, this.k);

  @override
  void paint(Canvas canvas, Size s) {
    final c = s.center(Offset.zero);
    final r = s.width * 0.24 * (1 + 0.035 * sin(t * 2 * pi));
    for (int i = 0; i < 3; i++) {
      final p = (t + i / 3) % 1;
      canvas.drawCircle(
        c,
        r * (1.15 + p * 0.95),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = C.violet.withOpacity((1 - p) * (0.10 + 0.30 * k)),
      );
    }
    canvas.drawCircle(
      c,
      r * 1.9,
      Paint()
        ..shader = RadialGradient(colors: [C.violet.withOpacity(0.22 + 0.2 * k), Colors.transparent])
            .createShader(Rect.fromCircle(center: c, radius: r * 1.9)),
    );
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = const RadialGradient(
          center: Alignment(-0.35, -0.45),
          radius: 1.0,
          colors: [Color(0xFF9378F5), Color(0xFF4B2FC4), Color(0xFF120A38)],
          stops: [0, 0.55, 1],
        ).createShader(rect),
    );
    canvas.drawCircle(
      c,
      r,
      Paint()
        ..shader = RadialGradient(
          center: const Alignment(0.55, 0.95),
          radius: 0.8,
          colors: [C.blue.withOpacity(0.65), Colors.transparent],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(_OrbPainter o) => o.t != t || o.k != k;
}

class Waveform extends StatelessWidget {
  final Animation<double> t;
  final bool active;
  const Waveform({super.key, required this.t, required this.active});

  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: t,
        builder: (_, __) => CustomPaint(size: const Size(220, 40), painter: _WavePainter(t.value, active)),
      );
}

class _WavePainter extends CustomPainter {
  final double t;
  final bool on;
  _WavePainter(this.t, this.on);

  @override
  void paint(Canvas canvas, Size s) {
    const n = 27;
    final w = s.width / n;
    for (int i = 0; i < n; i++) {
      final env = 1 - ((i - n / 2).abs() / (n / 2)) * 0.7;
      final a = on ? (0.35 + 0.65 * (0.5 + 0.5 * sin(t * 2 * pi * 3 + i * 0.7))) : 0.12;
      final h = max(3.0, s.height * env * a);
      final rr = RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(i * w + w / 2, s.height / 2), width: 3, height: h),
        const Radius.circular(2),
      );
      canvas.drawRRect(rr, Paint()..color = Color.lerp(C.violet, C.blue, i / n)!.withOpacity(on ? 0.9 : 0.4));
    }
  }

  @override
  bool shouldRepaint(_WavePainter o) => true;
}
