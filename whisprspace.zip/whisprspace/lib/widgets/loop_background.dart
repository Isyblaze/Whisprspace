import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../theme.dart';

/// Lets screens switch the ambient loop on/off (it settles once a call connects).
class BgControl {
  static final playing = ValueNotifier<bool>(true);
  static void set(bool v) => Future.microtask(() => playing.value = v);
}

/// One shared, muted, looping video that lives behind every screen.
class LoopBackground extends StatefulWidget {
  const LoopBackground({super.key});
  @override
  State<LoopBackground> createState() => _LoopBackgroundState();
}

class _LoopBackgroundState extends State<LoopBackground> with WidgetsBindingObserver {
  VideoPlayerController? _vc;
  bool _ready = false, _inForeground = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    BgControl.playing.addListener(_sync);
    _init();
  }

  Future<void> _init() async {
    try {
      final c = VideoPlayerController.asset(
        'assets/bg_loop.mp4',
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true), // never steal call audio focus
      );
      await c.initialize();
      await c.setLooping(true);
      await c.setVolume(0);
      if (!mounted) {
        c.dispose();
        return;
      }
      setState(() {
        _vc = c;
        _ready = true;
      });
      _sync();
    } catch (_) {} // falls back to the static gradient
  }

  void _sync() {
    final c = _vc;
    if (c == null) return;
    if (BgControl.playing.value && _inForeground) {
      c.play();
    } else if (!BgControl.playing.value) {
      Future.delayed(const Duration(milliseconds: 900), () {
        if (!BgControl.playing.value) _vc?.pause();
      });
    } else {
      c.pause();
    }
    if (mounted) setState(() {});
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    _inForeground = s == AppLifecycleState.resumed;
    _sync();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    BgControl.playing.removeListener(_sync);
    _vc?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(center: Alignment(0, -0.1), radius: 1.1, colors: [Color(0xFF140A2A), C.bg]),
          ),
        ),
        if (_ready)
          AnimatedOpacity(
            opacity: BgControl.playing.value ? 1 : 0,
            duration: const Duration(milliseconds: 800),
            curve: Curves.easeInOut,
            child: FittedBox(
              fit: BoxFit.cover,
              clipBehavior: Clip.hardEdge,
              child: SizedBox(width: _vc!.value.size.width, height: _vc!.value.size.height, child: VideoPlayer(_vc!)),
            ),
          ),
      ]);
}
