import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';
import 'widgets/loop_background.dart';
import 'services/config.dart';
import 'screens/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Config.load();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: C.bg,
  ));
  runApp(const WhisprSpace());
}

class WhisprSpace extends StatelessWidget {
  const WhisprSpace({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'WhisprSpace',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        builder: (context, child) => Stack(fit: StackFit.expand, children: [
          const LoopBackground(),
          child ?? const SizedBox.shrink(),
        ]),
        home: const SplashScreen(),
      );
}
