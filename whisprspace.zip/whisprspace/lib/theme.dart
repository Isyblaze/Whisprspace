import 'package:flutter/material.dart';

class C {
  static const bg = Color(0xFF06030D);
  static const surface = Color(0xFF110A20);
  static const line = Color(0xFF241A42);
  static const violet = Color(0xFF7C5CF0);
  static const blue = Color(0xFF2F6BFF);
  static const text = Color(0xFFEDEAFF);
  static const muted = Color(0xFF8F87BC);
  static const danger = Color(0xFFFF6B81);
}

ThemeData buildTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: Colors.transparent,
    colorScheme: const ColorScheme.dark(primary: C.violet, secondary: C.blue, surface: C.surface),
    textTheme: base.textTheme.apply(bodyColor: C.text, displayColor: C.text),
    splashFactory: NoSplash.splashFactory,
  );
}

Route<T> fade<T>(Widget w) => PageRouteBuilder<T>(
      pageBuilder: (_, __, ___) => w,
      transitionsBuilder: (_, a, s, child) =>
          FadeTransition(opacity: a, child: FadeTransition(opacity: ReverseAnimation(s), child: child)),
      transitionDuration: const Duration(milliseconds: 500),
    );

class Backdrop extends StatelessWidget {
  final Widget child;
  const Backdrop({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -0.25),
            radius: 1.15,
            colors: [Color(0x1206030D), Color(0x8006030D)],
          ),
        ),
        child: child,
      );
}
