import 'package:flutter/material.dart';
import '../services/match_service.dart';
import '../services/rtc_service.dart';
import '../theme.dart';
import '../widgets/orb.dart';
import 'call_screen.dart';

class MatchingScreen extends StatefulWidget {
  final Mood? mood;
  final Scope scope;
  const MatchingScreen({super.key, this.mood, required this.scope});
  @override
  State<MatchingScreen> createState() => _MatchingScreenState();
}

class _MatchingScreenState extends State<MatchingScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  late final MatchService _svc = createMatchService();
  bool _matched = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _svc.find(widget.mood, widget.scope).then((m) {
      if (m == null) return;
      if (mounted) {
        _matched = true;
        Navigator.pushReplacement(context, fade(CallScreen(match: m)));
      } else {
        m.session?.close();
      }
    }).catchError((e) {
      if (mounted) setState(() => _error = e is MatchError ? e.message : 'Something went wrong. Try again.');
    });
  }

  @override
  void dispose() {
    if (!_matched) _svc.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final where = widget.scope == Scope.global ? 'anywhere' : 'nearby';
    final feel = widget.mood?.label.toLowerCase() ?? 'any mood';
    if (_error != null) {
      return Scaffold(
        body: Backdrop(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(children: [
                const Spacer(flex: 3),
                const Icon(Icons.cloud_off_rounded, size: 44, color: C.muted),
                const SizedBox(height: 22),
                Text(_error!, textAlign: TextAlign.center, style: const TextStyle(fontSize: 17)),
                const Spacer(flex: 3),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: FilledButton(
                    onPressed: () => Navigator.pushReplacement(context, fade(MatchingScreen(mood: widget.mood, scope: widget.scope))),
                    style: FilledButton.styleFrom(backgroundColor: C.violet, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                    child: const Text('Try again', style: TextStyle(fontSize: 16)),
                  ),
                ),
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('Back', style: TextStyle(color: C.muted))),
                const SizedBox(height: 16),
              ]),
            ),
          ),
        ),
      );
    }
    return Scaffold(
      body: Backdrop(
        child: SafeArea(
          child: Column(children: [
            const Spacer(flex: 3),
            Orb(t: _c, intensity: 1, size: 320),
            const Text('Listening for someone…', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500)),
            const SizedBox(height: 8),
            Text('Looking $where for a voice feeling $feel', style: const TextStyle(color: C.muted, fontSize: 14)),
            const Spacer(flex: 3),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Stop listening', style: TextStyle(color: C.muted, fontSize: 15)),
            ),
            const SizedBox(height: 24),
          ]),
        ),
      ),
    );
  }
}
