import 'package:flutter/material.dart';
import '../services/match_service.dart';
import '../theme.dart';
import '../widgets/orb.dart';
import 'call_screen.dart';

class MatchingScreen extends StatefulWidget {
  final Mood? mood;
  final Scope scope;
  const MatchingScreen({super.key, this.mood, required this.scope});
  @override
  State<MatchingScreen> createState() => _MatchingScreenState();
}

class _MatchingScreenState extends State<MatchingScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  final MatchService _svc = MockMatchService();

  @override
  void initState() {
    super.initState();
    _svc.find(widget.mood, widget.scope).then((m) {
      if (m != null && mounted) Navigator.pushReplacement(context, fade(CallScreen(match: m)));
    });
  }

  @override
  void dispose() {
    _svc.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final where = widget.scope == Scope.global ? 'anywhere' : 'nearby';
    final feel = widget.mood?.label.toLowerCase() ?? 'any mood';
    return Scaffold(
      body: Backdrop(
        child: SafeArea(
          child: Column(children: [
            const Spacer(flex: 3),
            Orb(t: _c, intensity: 1, size: 320),
            const Text('Listening for someone…', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500)),
            const SizedBox(height: 8),
            Text('Looking $where for a voice feeling $feel', style: const TextStyle(color: C.muted, fontSize: 14)),
            const Spacer(flex: 3),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Stop listening', style: TextStyle(color: C.muted, fontSize: 15)),
            ),
            const SizedBox(height: 24),
          ]),
        ),
      ),
    );
  }
}
