import 'dart:async';
import 'dart:math';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/match_service.dart';
import '../theme.dart';
import '../widgets/loop_background.dart';
import '../widgets/orb.dart';
import 'void_screen.dart';

class CallScreen extends StatefulWidget {
  final Match match;
  const CallScreen({super.key, required this.match});
  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();
  int _secs = 0;
  bool _muted = false, _speaker = false, _partnerTalking = true, _ended = false;
  String _endNote = 'Nothing was kept.';
  Timer? _tick, _talk;
  StreamSubscription<void>? _sub;

  @override
  void initState() {
    super.initState();
    _tick = Timer.periodic(const Duration(seconds: 1), (_) => setState(() => _secs++));
    if (widget.match.session == null) {
      _talk = Timer.periodic(const Duration(seconds: 3), (_) => setState(() => _partnerTalking = Random().nextBool()));
    }
    _sub = widget.match.session?.onEnded.listen((_) {
      if (!_ended && mounted) _end('They left the whisper. Nothing was kept.');
    });
    HapticFeedback.lightImpact();
    BgControl.hold(); // the loop settles once you're connected
  }

  @override
  void dispose() {
    _tick?.cancel();
    _talk?.cancel();
    _sub?.cancel();
    widget.match.session?.close();
    BgControl.release();
    _c.dispose();
    super.dispose();
  }

  void _end([String note = 'Nothing was kept.']) {
    _tick?.cancel();
    _talk?.cancel();
    widget.match.session?.close();
    HapticFeedback.mediumImpact();
    setState(() {
      _ended = true;
      _endNote = note;
    });
  }

  void _blockPeer() {
    widget.match.session?.block();
    _end('Blocked for a few hours. You won\'t be matched with them again.');
  }

  String get _time => '${(_secs ~/ 60).toString().padLeft(2, '0')}:${(_secs % 60).toString().padLeft(2, '0')}';

  void _report() => showModalBottomSheet(
        context: context,
        backgroundColor: C.surface,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        builder: (ctx) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(24, 20, 24, 12),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Report this whisper', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              const Text('This flags the voice\'s anonymous ID. Repeated reports from different people pause it from the app.', style: TextStyle(color: C.muted, fontSize: 13)),
              const SizedBox(height: 10),
              for (final r in ['Harassment or abuse', 'Sexual content', 'Hate or threats', 'Underage voice', 'Something else'])
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(r),
                  trailing: const Icon(Icons.chevron_right_rounded, color: C.muted),
                  onTap: () {
                    Navigator.pop(ctx);
                    widget.match.session?.report(r);
                    _end('Report sent. You won\'t be matched with them again. Thank you for keeping this space safe.');
                  },
                ),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Backdrop(
          child: SafeArea(
            child: AnimatedSwitcher(duration: const Duration(milliseconds: 500), child: _ended ? _closing() : _live()),
          ),
        ),
      );

  Widget _live() {
    final m = widget.match;
    return Column(key: const ValueKey('live'), children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 12, 8, 0),
        child: Row(children: [
          Text(_time, style: const TextStyle(color: C.muted, fontSize: 15, fontFeatures: [FontFeature.tabularFigures()])),
          const Spacer(),
          PopupMenuButton<String>(
            color: C.surface,
            icon: const Icon(Icons.more_horiz_rounded, color: C.muted),
            onSelected: (v) => v == 'r' ? _report() : _blockPeer(),
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'r', child: Text('Report')),
              PopupMenuItem(value: 'b', child: Text('Block for this session')),
            ],
          ),
        ]),
      ),
      const Spacer(),
      Orb(t: _c, intensity: _partnerTalking ? 1 : 0.2, size: 300),
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: (m.mood?.color ?? C.violet).withOpacity(0.15),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: (m.mood?.color ?? C.violet).withOpacity(0.6)),
        ),
        child: Text(m.mood == null ? 'Open to anything' : 'Feeling ${m.mood!.label.toLowerCase()}', style: const TextStyle(fontSize: 13)),
      ),
      const SizedBox(height: 14),
      Text(m.scope == Scope.global ? 'Someone, somewhere' : 'Someone nearby', style: const TextStyle(color: C.muted, fontSize: 14)),
      const SizedBox(height: 24),
      Waveform(t: _c, active: _partnerTalking),
      const Spacer(),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: [
        _btn(_muted ? Icons.mic_off_rounded : Icons.mic_rounded, 'Mute', _muted, () {
          setState(() => _muted = !_muted);
          widget.match.session?.setMuted(_muted);
        }),
        const SizedBox(width: 18),
        _btn(Icons.volume_up_rounded, 'Speaker', _speaker, () {
          setState(() => _speaker = !_speaker);
          widget.match.session?.setSpeaker(_speaker);
        }),
      ]),
      const SizedBox(height: 24),
      GestureDetector(
        onTap: () => _end(),
        child: Container(
          width: 72,
          height: 72,
          decoration: const BoxDecoration(shape: BoxShape.circle, color: C.danger),
          child: const Icon(Icons.call_end_rounded, size: 30, color: Colors.white),
        ),
      ),
      const SizedBox(height: 10),
      const Text('Leave', style: TextStyle(color: C.muted, fontSize: 12)),
      const SizedBox(height: 20),
    ]);
  }

  Widget _btn(IconData i, String l, bool on, VoidCallback f) => Column(children: [
        GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            f();
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: on ? C.violet.withOpacity(0.28) : C.surface,
              border: Border.all(color: on ? C.violet : C.line),
            ),
            child: Icon(i, color: on ? C.text : C.muted),
          ),
        ),
        const SizedBox(height: 6),
        Text(l, style: const TextStyle(color: C.muted, fontSize: 12)),
      ]);

  Widget _closing() => Padding(
        key: const ValueKey('end'),
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(children: [
          const Spacer(flex: 3),
          const Icon(Icons.nights_stay_rounded, size: 44, color: C.violet),
          const SizedBox(height: 24),
          const Text('Whisper ended', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Text(_endNote, textAlign: TextAlign.center, style: const TextStyle(color: C.muted, fontSize: 15)),
          const Spacer(flex: 3),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: FilledButton(
              onPressed: () => Navigator.pushReplacement(context, voidRoute(VoidScreen(mood: widget.match.mood, quick: true))),
              style: FilledButton.styleFrom(backgroundColor: C.violet, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
              child: const Text('Whisper again', style: TextStyle(fontSize: 16)),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Done', style: TextStyle(color: C.muted)),
          ),
          const SizedBox(height: 16),
        ]),
      );
}
