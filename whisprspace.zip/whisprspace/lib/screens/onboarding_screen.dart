import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme.dart';
import 'home_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  bool _age = false;

  static const _points = [
    ('No accounts, no profiles', 'Nothing links a whisper to you.'),
    ('Heard, then gone', 'Calls are never recorded or saved.'),
    ('Your location stays blurry', 'Nearby uses a wide area, never a pin.'),
    ('You are always in control', 'Mute, leave, report or block in one tap.'),
  ];

  Future<void> _continue() async {
    try {
      (await SharedPreferences.getInstance()).setBool('age_ok', true);
    } catch (_) {}
    if (!mounted) return;
    Navigator.pushReplacement(context, fade(const HomeScreen()));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Backdrop(
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(28, 40, 28, 24),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('A quieter way\nto be heard.', style: TextStyle(fontSize: 34, height: 1.15, fontWeight: FontWeight.w600)),
                const SizedBox(height: 36),
                for (final p in _points)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 22),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Container(
                        margin: const EdgeInsets.only(top: 6, right: 16),
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(shape: BoxShape.circle, color: C.violet),
                      ),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(p.$1, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 3),
                          Text(p.$2, style: const TextStyle(color: C.muted, fontSize: 14)),
                        ]),
                      ),
                    ]),
                  ),
                const Spacer(),
                InkWell(
                  onTap: () => setState(() => _age = !_age),
                  child: Row(children: [
                    Checkbox(value: _age, activeColor: C.violet, onChanged: (v) => setState(() => _age = v ?? false)),
                    const Expanded(child: Text('I am 18 or older and will treat others with respect.', style: TextStyle(fontSize: 14))),
                  ]),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: FilledButton(
                    onPressed: _age ? _continue : null,
                    style: FilledButton.styleFrom(
                      backgroundColor: C.violet,
                      disabledBackgroundColor: C.line,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text('Enter quietly', style: TextStyle(fontSize: 16)),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );
}
