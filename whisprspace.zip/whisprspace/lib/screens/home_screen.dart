import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/config.dart';
import '../services/match_service.dart';
import '../theme.dart';
import '../widgets/orb.dart';
import 'matching_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 6))..repeat();
  Mood? _mood; // null = any mood
  Scope _scope = Scope.global;

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _whisper() {
    HapticFeedback.mediumImpact();
    Navigator.push(context, fade(MatchingScreen(mood: _mood, scope: _scope)));
  }

  void _settings() => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: C.surface,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        builder: (_) => const _SettingsSheet(),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Backdrop(
          child: SafeArea(
            child: Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(24, 12, 8, 0),
                child: Row(children: [
                  const Text('whisprspace', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Color(0xFF8C7BFF))),
                  const Spacer(),
                  IconButton(onPressed: _settings, icon: const Icon(Icons.tune_rounded, color: C.muted)),
                ]),
              ),
              const Spacer(flex: 2),
              GestureDetector(onTap: _whisper, child: Orb(t: _c, size: 320)),
              const SizedBox(height: 4),
              const Text('Tap to whisper', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w500)),
              const SizedBox(height: 6),
              Text(
                _scope == Scope.global ? 'Someone, somewhere, is listening.' : 'Someone close by is listening.',
                style: const TextStyle(color: C.muted, fontSize: 14),
              ),
              const Spacer(flex: 2),
              const Padding(
                padding: EdgeInsets.only(left: 24, bottom: 10),
                child: Align(alignment: Alignment.centerLeft, child: Text('How are you feeling?', style: TextStyle(color: C.muted, fontSize: 13))),
              ),
              SizedBox(
                height: 42,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: [
                    _chip('Any', C.violet, _mood == null, () => setState(() => _mood = null)),
                    for (final m in Mood.values) _chip(m.label, m.color, _mood == m, () => setState(() => _mood = m)),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: C.line)),
                  child: Row(children: [
                    _seg('Global', Icons.public_rounded, Scope.global),
                    _seg('Nearby', Icons.near_me_rounded, Scope.nearby),
                  ]),
                ),
              ),
              const SizedBox(height: 16),
              const Padding(
                padding: EdgeInsets.only(bottom: 14),
                child: Text('Nothing is recorded. Nothing is saved.', style: TextStyle(color: C.muted, fontSize: 12)),
              ),
            ]),
          ),
        ),
      );

  Widget _chip(String label, Color color, bool sel, VoidCallback onTap) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: GestureDetector(
          onTap: () {
            HapticFeedback.selectionClick();
            onTap();
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: sel ? color.withOpacity(0.18) : C.surface,
              borderRadius: BorderRadius.circular(21),
              border: Border.all(color: sel ? color : C.line),
            ),
            child: Row(children: [
              Container(width: 7, height: 7, decoration: BoxDecoration(shape: BoxShape.circle, color: color)),
              const SizedBox(width: 8),
              Text(label, style: TextStyle(fontSize: 14, color: sel ? C.text : C.muted)),
            ]),
          ),
        ),
      );

  Widget _seg(String label, IconData icon, Scope s) {
    final sel = _scope == s;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          HapticFeedback.selectionClick();
          setState(() => _scope = s);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(color: sel ? C.violet.withOpacity(0.25) : Colors.transparent, borderRadius: BorderRadius.circular(12)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 18, color: sel ? C.text : C.muted),
            const SizedBox(width: 8),
            Text(label, style: TextStyle(color: sel ? C.text : C.muted, fontWeight: FontWeight.w500)),
          ]),
        ),
      ),
    );
  }
}

class _SettingsSheet extends StatefulWidget {
  const _SettingsSheet();
  @override
  State<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<_SettingsSheet> {
  late final TextEditingController _url = TextEditingController(text: Config.serverUrl);

  @override
  void dispose() {
    _url.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(24, 20, 24, 16 + MediaQuery.of(context).viewInsets.bottom),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Privacy', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              const _Info(Icons.location_searching_rounded, 'Nearby matching', 'Uses a wide area only, never your exact position.'),
              const _Info(Icons.shield_outlined, 'Relayed calls', 'When relay is on, you never see each other\'s network address.'),
              const _Info(Icons.history_toggle_off_rounded, 'No history', 'Closing a whisper erases it for good.'),
              const _Info(Icons.graphic_eq_rounded, 'Voice masking', 'Coming in a later update.'),
              const Divider(color: C.line, height: 28),
              const Text('Server (testing)', style: TextStyle(fontWeight: FontWeight.w500)),
              const SizedBox(height: 8),
              TextField(
                controller: _url,
                onChanged: Config.save,
                keyboardType: TextInputType.url,
                autocorrect: false,
                decoration: InputDecoration(
                  hintText: 'your-app.onrender.com',
                  filled: true,
                  fillColor: C.bg,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.line)),
                ),
              ),
              const SizedBox(height: 6),
              const Text('Leave empty to use the built-in simulator.', style: TextStyle(color: C.muted, fontSize: 12)),
            ]),
          ),
        ),
      );
}

class _Info extends StatelessWidget {
  final IconData i;
  final String a, b;
  const _Info(this.i, this.a, this.b);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(i, size: 20, color: C.violet),
          const SizedBox(width: 14),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(a, style: const TextStyle(fontWeight: FontWeight.w500)),
              Text(b, style: const TextStyle(color: C.muted, fontSize: 13)),
            ]),
          ),
        ]),
      );
}
