import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/match_service.dart';
import '../services/presence.dart';
import '../services/rtc_service.dart';
import '../theme.dart';
import '../widgets/globe_view.dart';
import '../widgets/loop_background.dart';
import 'call_screen.dart';

Route<T> voidRoute<T>(Widget w) => PageRouteBuilder<T>(
      pageBuilder: (_, __, ___) => w,
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
      transitionDuration: const Duration(milliseconds: 700),
    );

class VoidScreen extends StatefulWidget {
  final Mood? mood;
  final bool quick;
  const VoidScreen({super.key, this.mood, this.quick = false});
  @override
  State<VoidScreen> createState() => _VoidScreenState();
}

class _VoidScreenState extends State<VoidScreen> with TickerProviderStateMixin {
  late final AnimationController _intro =
      AnimationController(vsync: this, duration: Duration(milliseconds: widget.quick ? 900 : 2400));
  late final AnimationController _clock = AnimationController(vsync: this, duration: const Duration(seconds: 40))..repeat();
  final GlobeController _g = GlobeController();
  final Presence _presence = Presence();
  MatchService? _svc;
  bool _searching = false, _matched = false;
  String? _error;
  double _km = 0; // 0 = anywhere
  int _heatGen = 0;

  static const _listenCol = Color(0xFF9B7BFF), _talkCol = Color(0xFFFF80C8);

  @override
  void initState() {
    super.initState();
    BgControl.hold();
    _intro.forward();
    _presence.heat.addListener(_onHeat);
    _presence.total.addListener(_refresh);
    _presence.start();
    _onHeat();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  void _onHeat() {
    final gen = ++_heatGen;
    buildHeatImage(_presence.heat.value).then((img) {
      if (!mounted || gen != _heatGen) return;
      _g.heat = img;
      _g.changed();
      setState(() {});
    });
  }

  @override
  void dispose() {
    if (!_matched) _svc?.cancel();
    BgControl.release();
    _presence.heat.removeListener(_onHeat);
    _presence.total.removeListener(_refresh);
    _presence.dispose();
    _intro.dispose();
    _clock.dispose();
    _g.dispose();
    super.dispose();
  }

  Region _cellRegion(double lat, double lon, double km) {
    final l = ((lon + 180) % 360 + 360) % 360 - 180;
    final ix = ((l + 180) / 2).floor().clamp(0, 179).toInt();
    final iy = ((lat + 90) / 2).floor().clamp(0, 89).toInt();
    return Region(cellLat(iy), cellLon(ix), km);
  }

  void _pick(double lat, double lon) {
    if (_searching || _km == 0) return;
    HapticFeedback.selectionClick();
    setState(() => _g.sel = _cellRegion(lat, lon, _km));
    _g.changed();
  }

  void _setKm(double km) {
    if (_searching) return;
    HapticFeedback.selectionClick();
    setState(() {
      _km = km;
      _error = null;
      if (km == 0) {
        _g.sel = null;
      } else {
        final cur = _g.sel;
        _g.sel = cur != null
            ? Region(cur.lat, cur.lon, km)
            : _cellRegion(_g.lat * 180 / math.pi, _g.lon * 180 / math.pi, km);
      }
    });
    _g.changed();
  }

  List<int> _regionCounts() {
    final sel = _g.sel;
    if (sel == null) return [0, 0];
    var l = 0, t = 0;
    for (final c in _presence.heat.value) {
      if (_dist(sel.lat, sel.lon, cellLat(c.iy), cellLon(c.ix)) <= sel.km) {
        l += c.listen;
        t += c.talk;
      }
    }
    return [l, t];
  }

  double _dist(double la1, double lo1, double la2, double lo2) {
    const rad = math.pi / 180;
    final dl = (la2 - la1) * rad, dn = (lo2 - lo1) * rad;
    final h = math.pow(math.sin(dl / 2), 2) + math.cos(la1 * rad) * math.cos(la2 * rad) * math.pow(math.sin(dn / 2), 2);
    return 2 * 6371 * math.asin(math.min(1.0, math.sqrt(h.toDouble())));
  }

  Future<void> _begin() async {
    HapticFeedback.mediumImpact();
    final svc = _svc = createMatchService();
    final region = _km > 0 ? _g.sel : null;
    setState(() {
      _searching = true;
      _error = null;
    });
    _g.searching = true;
    _g.changed();
    try {
      final m = await svc.find(widget.mood, region == null ? Scope.global : Scope.nearby, region: region);
      if (!mounted) {
        m?.session?.close();
        return;
      }
      if (_svc != svc) return;
      if (m == null) {
        _stopUi();
        return;
      }
      _matched = true;
      HapticFeedback.heavyImpact();
      Navigator.pushReplacement(context, fade(CallScreen(match: m)));
    } catch (e) {
      if (!mounted || _svc != svc) return;
      _stopUi();
      setState(() => _error = e is MatchError ? e.message : 'Something went wrong. Try again.');
    }
  }

  void _stopUi() {
    _g.searching = false;
    _g.changed();
    if (mounted) setState(() => _searching = false);
  }

  void _cancel() {
    _svc?.cancel();
    _svc = null;
    _stopUi();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: C.bg,
        body: Stack(fit: StackFit.expand, children: [
          AnimatedBuilder(animation: _clock, builder: (_, __) => CustomPaint(painter: _StarsPainter(_clock.value))),
          AnimatedBuilder(animation: _intro, builder: (_, __) => CustomPaint(painter: _WarpPainter(_intro.value))),
          Positioned.fill(child: GlobeView(ctrl: _g, intro: _intro, onPick: _pick)),
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _intro, curve: const Interval(0.55, 1.0)),
              child: Column(children: [_topBar(), const Spacer(), _panel()]),
            ),
          ),
        ]),
      );

  Widget _topBar() => Padding(
        padding: const EdgeInsets.fromLTRB(8, 4, 16, 0),
        child: Row(children: [
          IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, color: C.muted)),
          if (widget.mood != null)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: widget.mood!.color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: widget.mood!.color.withOpacity(0.6)),
              ),
              child: Text(widget.mood!.label, style: const TextStyle(fontSize: 12.5)),
            ),
          const Spacer(),
          _dot(_listenCol, 'listening'),
          const SizedBox(width: 12),
          _dot(_talkCol, 'whispering'),
        ]),
      );

  Widget _dot(Color c, String l) => Row(children: [
        Container(width: 8, height: 8, decoration: BoxDecoration(shape: BoxShape.circle, color: c, boxShadow: [BoxShadow(color: c.withOpacity(0.7), blurRadius: 6)])),
        const SizedBox(width: 6),
        Text(l, style: const TextStyle(color: C.muted, fontSize: 12)),
      ]);

  String _info() {
    if (_searching) return _km == 0 ? 'Listening across the whole world…' : 'Listening in your chosen region…';
    if (_km == 0) {
      final n = _presence.total.value;
      final base = _presence.demo ? 'Demo data. ' : '';
      return n > 0 ? '$base$n voices active around the world' : 'Spin the globe. Scanning the whole world when you begin.';
    }
    if (_g.sel == null) return 'Tap the globe to choose a place';
    final c = _regionCounts();
    if (c[0] + c[1] == 0) return 'Quiet here right now. You could be the first.';
    return '${c[0]} listening · ${c[1]} whispering in this region';
  }

  Widget _panel() => Container(
        margin: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        decoration: BoxDecoration(
          color: C.surface.withOpacity(0.90),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: C.line),
        ),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            _scopeChip('Anywhere', 0),
            _scopeChip('300 km', 300),
            _scopeChip('800 km', 800),
            _scopeChip('1,500 km', 1500),
          ]),
          const SizedBox(height: 12),
          Text(_info(), style: const TextStyle(color: C.muted, fontSize: 13.5)),
          if (_km > 0 && !_searching)
            ValueListenableBuilder<bool>(
              valueListenable: AppState.shareRegion,
              builder: (_, v, __) => SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                activeColor: C.violet,
                value: v,
                onChanged: (x) => AppState.shareRegion.value = x,
                title: const Text('Let people in this region find me', style: TextStyle(fontSize: 13.5)),
                subtitle: const Text('Shares only a rough area (about 200 km), never your exact position.', style: TextStyle(color: C.muted, fontSize: 11.5)),
              ),
            ),
          if (_error != null)
            Padding(padding: const EdgeInsets.only(top: 8), child: Text(_error!, style: const TextStyle(color: C.danger, fontSize: 13))),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            height: 54,
            child: _searching
                ? OutlinedButton(
                    onPressed: _cancel,
                    style: OutlinedButton.styleFrom(side: const BorderSide(color: C.line), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                    child: const Text('Stop listening', style: TextStyle(color: C.text, fontSize: 16)),
                  )
                : FilledButton(
                    onPressed: (_km > 0 && _g.sel == null) ? null : _begin,
                    style: FilledButton.styleFrom(
                      backgroundColor: C.violet,
                      disabledBackgroundColor: C.line,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    child: const Text('Begin whispering', style: TextStyle(fontSize: 16)),
                  ),
          ),
        ]),
      );

  Widget _scopeChip(String label, double km) {
    final sel = _km == km;
    return Expanded(
      child: GestureDetector(
        onTap: () => _setKm(km),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          margin: const EdgeInsets.only(right: 6),
          padding: const EdgeInsets.symmetric(vertical: 10),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: sel ? C.violet.withOpacity(0.25) : C.bg.withOpacity(0.6),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: sel ? C.violet : C.line),
          ),
          child: Text(label, style: TextStyle(fontSize: 12.5, color: sel ? C.text : C.muted, fontWeight: FontWeight.w500)),
        ),
      ),
    );
  }
}

class _StarsPainter extends CustomPainter {
  final double t;
  _StarsPainter(this.t);
  static final _r = math.Random(7);
  static final List<List<double>> _s = List.generate(
      150, (_) => [_r.nextDouble(), _r.nextDouble(), 0.5 + _r.nextDouble() * 1.3, _r.nextDouble() * 6.28, 0.5 + _r.nextDouble() * 2]);

  @override
  void paint(Canvas canvas, Size size) {
    for (final s in _s) {
      final a = 0.25 + 0.55 * (0.5 + 0.5 * math.sin(t * 40 * s[4] + s[3]));
      canvas.drawCircle(Offset(s[0] * size.width, s[1] * size.height), s[2] * 0.6, Paint()..color = Colors.white.withOpacity(a * 0.7));
    }
  }

  @override
  bool shouldRepaint(_StarsPainter o) => true;
}

/// Starlight streaming inward as you are pulled into the void.
class _WarpPainter extends CustomPainter {
  final double p;
  _WarpPainter(this.p);
  static final _r = math.Random(3);
  static final List<List<double>> _l = List.generate(90, (_) => [_r.nextDouble() * 6.2832, 0.35 + _r.nextDouble() * 0.65]);

  @override
  void paint(Canvas canvas, Size size) {
    if (p >= 1) return;
    final c = size.center(Offset.zero), maxR = size.longestSide * 0.75;
    final e = Curves.easeInCubic.transform(p);
    for (final l in _l) {
      final head = l[1] * maxR * (1 - e), tail = head + l[1] * maxR * 0.35 * (1 - p);
      final dir = Offset(math.cos(l[0]), math.sin(l[0]));
      canvas.drawLine(
        c + dir * head,
        c + dir * tail,
        Paint()
          ..strokeWidth = 1.4
          ..color = const Color(0xFFB7A6FF).withOpacity((1 - p) * 0.55),
      );
    }
  }

  @override
  bool shouldRepaint(_WarpPainter o) => o.p != p;
}
