import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme.dart';
import 'home_screen.dart';
import 'onboarding_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..forward();

  @override
  void initState() {
    super.initState();
    _go();
  }

  Future<void> _go() async {
    bool ok = false;
    try {
      ok = (await SharedPreferences.getInstance()).getBool('age_ok') ?? false;
    } catch (_) {}
    await Future.delayed(const Duration(milliseconds: 1800));
    if (!mounted) return;
    Navigator.pushReplacement(context, fade(ok ? const HomeScreen() : const OnboardingScreen()));
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Backdrop(
          child: Center(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _c, curve: Curves.easeOut),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/icon.png', width: 112)),
                const SizedBox(height: 22),
                const Text('whisprspace',
                    style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600, letterSpacing: 0.5, color: Color(0xFF8C7BFF))),
                const SizedBox(height: 8),
                const Text('Your voice is your identity.', style: TextStyle(color: C.muted, fontSize: 14)),
              ]),
            ),
          ),
        ),
      );
}
