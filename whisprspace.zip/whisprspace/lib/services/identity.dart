import 'dart:convert';
import 'package:cryptography/cryptography.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Anonymous device identity: a random key made on this phone, never shown to
/// the user and never tied to a name, number or account.
class Identity {
  static SimpleKeyPair? _kp;
  static List<int>? _pub;

  static Future<void> init() async {
    final algo = Ed25519();
    final p = await SharedPreferences.getInstance();
    final seed = p.getString('dev_seed');
    SimpleKeyPair kp;
    if (seed == null) {
      kp = await algo.newKeyPair();
      await p.setString('dev_seed', base64.encode(await kp.extractPrivateKeyBytes()));
    } else {
      kp = await algo.newKeyPairFromSeed(base64.decode(seed));
    }
    _kp = kp;
    _pub = (await kp.extractPublicKey()).bytes;
  }

  static Future<Map<String, String>> sign(String nonce) async {
    final sig = await Ed25519().sign(utf8.encode(nonce), keyPair: _kp!);
    return {'pub': base64.encode(_pub!), 'sig': base64.encode(sig.bytes)};
  }
}
