import 'dart:convert';
import 'dart:isolate';
import 'package:crypto/crypto.dart';
import 'package:cryptography/cryptography.dart';
import 'package:shared_preferences/shared_preferences.dart';

int _zeroBits(List<int> h) {
  var n = 0;
  for (final b in h) {
    if (b == 0) {
      n += 8;
      continue;
    }
    n += 8 - b.bitLength;
    break;
  }
  return n;
}

/// Small puzzle that makes mass-creating fake devices expensive, but costs a real phone well under a second.
int _solvePow(List<String> a) {
  final prefix = utf8.encode('${a[0]}${a[1]}:');
  final bits = int.parse(a[2]);
  var i = 0;
  while (true) {
    if (_zeroBits(sha256.convert([...prefix, ...utf8.encode('$i')]).bytes) >= bits) return i;
    i++;
  }
}

/// Anonymous device identity: a random key made on this phone, never shown to
/// the user and never tied to a name, number or account.
class Identity {
  static SimpleKeyPair? _kp;
  static List<int>? _pub;
  static String? _token;

  static Future<void> init() async {
    final algo = Ed25519();
    final p = await SharedPreferences.getInstance();
    final seed = p.getString('dev_seed');
    SimpleKeyPair kp;
    if (seed == null) {
      kp = await algo.newKeyPair();
      await p.setString('dev_seed', base64.encode(await kp.extractPrivateKeyBytes()));
    } else {
      kp = await algo.newKeyPairFromSeed(base64.decode(seed));
    }
    _kp = kp;
    _pub = (await kp.extractPublicKey()).bytes;
    _token = p.getString('auth_token');
  }

  static bool get _tokenFresh {
    final t = _token;
    if (t == null) return false;
    final p = t.split('.');
    if (p.length != 3) return false;
    return (int.tryParse(p[1]) ?? 0) > DateTime.now().millisecondsSinceEpoch + 60000;
  }

  static Future<void> saveToken(String t) async {
    _token = t;
    try {
      (await SharedPreferences.getInstance()).setString('auth_token', t);
    } catch (_) {}
  }

  static Future<void> clearToken() async {
    _token = null;
    try {
      (await SharedPreferences.getInstance()).remove('auth_token');
    } catch (_) {}
  }

  static Future<Map<String, String>> sign(String nonce) async {
    if (_kp == null) await init(); // never fail just because start-up setup was skipped
    final sig = await Ed25519().sign(utf8.encode(nonce), keyPair: _kp!);
    return {'pub': base64.encode(_pub!), 'sig': base64.encode(sig.bytes)};
  }

  /// Signature, plus either a fresh session token or the proof-of-work the server asked for.
  static Future<Map<String, String>> authFields(String nonce, int powBits) async {
    final out = await sign(nonce);
    if (_tokenFresh) {
      out['token'] = _token!;
    } else if (powBits > 0) {
      final pub = out['pub']!;
      try {
        out['pow'] = (await Isolate.run(() => _solvePow([nonce, pub, '$powBits']))).toString();
      } catch (_) {
        out['pow'] = _solvePow([nonce, pub, '$powBits']).toString(); // fall back to solving here
      }
    }
    return out;
  }
}
