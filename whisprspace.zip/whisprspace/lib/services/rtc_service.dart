import 'dart:async';
import 'dart:convert';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'config.dart';
import 'identity.dart';
import 'location.dart';
import 'match_service.dart';

/// Uses the real server when an address is set, otherwise the simulator.
MatchService createMatchService() =>
    Config.serverUrl.trim().isEmpty ? MockMatchService() : RtcCall(Config.serverUrl.trim());

class RtcCall implements MatchService, CallSession {
  final String url;
  RtcCall(this.url);

  WebSocketChannel? _ws;
  RTCPeerConnection? _pc;
  MediaStream? _local;
  Completer<Match?>? _done;
  final _ended = StreamController<void>.broadcast();
  final List<RTCIceCandidate> _pending = [];
  Future<void> _chain = Future.value();
  bool _remoteSet = false, _closed = false, _connected = false;
  Scope _scope = Scope.global;
  Mood? _mood;
  Map<String, dynamic>? _want;
  Timer? _authTimer;

  @override
  Stream<void> get onEnded => _ended.stream;

  String get _wsUrl {
    var u = url;
    if (u.startsWith('https://')) {
      u = 'wss://${u.substring(8)}';
    } else if (u.startsWith('http://')) {
      u = 'ws://${u.substring(7)}';
    } else if (!u.startsWith('ws')) {
      u = 'wss://$u';
    }
    return u;
  }

  @override
  Future<Match?> find(Mood? mood, Scope scope, {Region? region}) async {
    _scope = scope;
    final done = _done = Completer<Match?>();
    try {
      final home = AppState.shareRegion.value ? await homeCell() : null;
      try {
        _local = await navigator.mediaDevices.getUserMedia({
          'audio': {'echoCancellation': true, 'noiseSuppression': true, 'autoGainControl': true},
          'video': false,
        });
      } catch (_) {
        throw MatchError('Microphone access is needed to whisper.');
      }
      if (_closed) return null;
      final ws = _ws = WebSocketChannel.connect(Uri.parse(_wsUrl));
      await ws.ready.timeout(const Duration(seconds: 70));
      if (_closed) return null;
      ws.stream.listen(
        (raw) {
          _chain = _chain.then((_) => _handle(raw)).catchError((_) {
            _fail(MatchError('The connection failed. Try again.'));
          });
        },
        onDone: () {
          if (_done != null && !_done!.isCompleted) {
            _fail(MatchError('Lost connection to the server.', retry: true));
          } else {
            _remoteGone();
          }
        },
        onError: (_) => _fail(MatchError('Lost connection to the server.', retry: true)),
      );
      _want = {
        't': 'find',
        'mood': mood?.name,
        'scope': scope.name,
        'home': home,
        'area': scope == Scope.nearby && region != null ? {'lat': region.lat, 'lon': region.lon, 'r': region.km} : null,
      };
      _authTimer = Timer(const Duration(seconds: 15), () => _fail(MatchError('Could not reach the server. Try again.')));
      return await done.future;
    } on TimeoutException {
      await close();
      throw MatchError('Could not reach the server. It may be waking up, try again.');
    } catch (e) {
      await close();
      if (e is MatchError) rethrow;
      throw MatchError('Could not connect. Check the server address.');
    }
  }

  Future<void> _handle(dynamic raw) async {
    final m = jsonDecode(raw as String) as Map;
    switch (m['t']) {
      case 'hello':
        {
          final s = await Identity.authFields(m['nonce'] as String, (m['pow'] as num?)?.toInt() ?? 0);
          _send({'t': 'auth', ...s});
          break;
        }
      case 'ready':
        _authTimer?.cancel();
        if (m['token'] is String) await Identity.saveToken(m['token'] as String);
        if (_want != null) _send(_want!);
        break;
      case 'banned':
        _fail(MatchError('Whispers from this device are paused for a while after reports from others. Please try again later.'));
        break;
      case 'ratelimit':
        _fail(MatchError('Slow down a little, then try again.'));
        break;
      case 'reject':
        if (m['why'] == 'token') {
          await Identity.clearToken();
          _fail(MatchError('Reconnecting…', retry: true));
        } else {
          _fail(MatchError('Please update WhisprSpace to keep whispering.'));
        }
        break;
      case 'busy':
        _fail(MatchError('WhisprSpace is very busy right now. Trying again…', retry: true));
        break;
      case 'restart':
        _fail(MatchError('The server is updating. Reconnecting…', retry: true));
        break;
      case 'widen':
        AppState.searchNote.value = m['what'] == 'mood'
            ? 'No one yet. Widening to any mood…'
            : 'No one yet. Widening your region to ${m['km']} km…';
        break;
      case 'match':
        AppState.searchNote.value = null;
        await _startPeer(m);
        break;
      case 'signal':
        await _onSignal(Map<String, dynamic>.from(m['d'] as Map));
        break;
      case 'none':
        _fail(MatchError('No one is listening right now. Try again in a moment.'));
        break;
      case 'bye':
        _remoteGone();
        break;
    }
  }

  Future<void> _startPeer(Map m) async {
    final name = m['mood'];
    _mood = name == null ? null : Mood.values.where((x) => x.name == name).firstOrNull;
    final servers = (m['ice'] as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final pc = _pc = await createPeerConnection({
      'iceServers': servers,
      'iceTransportPolicy': m['relay'] == true ? 'relay' : 'all',
      'sdpSemantics': 'unified-plan',
    });
    for (final t in _local!.getAudioTracks()) {
      await pc.addTrack(t, _local!);
    }
    pc.onIceCandidate = (c) {
      if (c.candidate != null) _send({'t': 'signal', 'd': {'candidate': c.toMap()}});
    };
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected && !_connected) {
        _connected = true;
        Helper.setSpeakerphoneOn(false);
        if (_done != null && !_done!.isCompleted) _done!.complete(Match(_mood, _scope, session: this));
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
        if (_connected) {
          _remoteGone();
        } else {
          _fail(MatchError('Could not connect to them. Try again.'));
        }
      }
    };
    if (m['role'] == 'offer') {
      final o = await pc.createOffer({'offerToReceiveAudio': 1});
      await pc.setLocalDescription(o);
      _send({'t': 'signal', 'd': {'sdp': o.sdp, 'type': o.type}});
    }
  }

  Future<void> _onSignal(Map<String, dynamic> d) async {
    final pc = _pc;
    if (pc == null) return;
    if (d['sdp'] != null) {
      await pc.setRemoteDescription(RTCSessionDescription(d['sdp'] as String, d['type'] as String));
      _remoteSet = true;
      for (final c in _pending) {
        await pc.addCandidate(c);
      }
      _pending.clear();
      if (d['type'] == 'offer') {
        final a = await pc.createAnswer({'offerToReceiveAudio': 1});
        await pc.setLocalDescription(a);
        _send({'t': 'signal', 'd': {'sdp': a.sdp, 'type': a.type}});
      }
    } else if (d['candidate'] != null) {
      final cm = Map<String, dynamic>.from(d['candidate'] as Map);
      final c = RTCIceCandidate(cm['candidate'] as String?, cm['sdpMid'] as String?, cm['sdpMLineIndex'] as int?);
      if (_remoteSet) {
        await pc.addCandidate(c);
      } else {
        _pending.add(c);
      }
    }
  }

  void _send(Map<String, dynamic> m) {
    try {
      _ws?.sink.add(jsonEncode(m));
    } catch (_) {}
  }

  void _fail(MatchError e) {
    if (_done != null && !_done!.isCompleted) _done!.completeError(e);
  }

  void _remoteGone() {
    if (!_closed && _connected && !_ended.isClosed) _ended.add(null);
  }

  @override
  Future<void> report(String reason) async => _send({'t': 'report', 'reason': reason});

  @override
  Future<void> block() async => _send({'t': 'block'});

  @override
  void setMuted(bool m) {
    for (final t in _local?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = !m;
    }
  }

  @override
  void setSpeaker(bool on) => Helper.setSpeakerphoneOn(on);

  @override
  void cancel() {
    close();
  }

  @override
  Future<void> close() async {
    if (_closed) return;
    _closed = true;
    _authTimer?.cancel();
    _send({'t': 'leave'});
    if (_done != null && !_done!.isCompleted) _done!.complete(null);
    try {
      for (final t in _local?.getTracks() ?? <MediaStreamTrack>[]) {
        await t.stop();
      }
      await _local?.dispose();
    } catch (_) {}
    try {
      await _pc?.close();
    } catch (_) {}
    try {
      await _ws?.sink.close();
    } catch (_) {}
    if (!_ended.isClosed) await _ended.close();
  }
}
