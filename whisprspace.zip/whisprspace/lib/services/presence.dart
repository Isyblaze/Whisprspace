import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'config.dart';
import 'identity.dart';
import 'match_service.dart';

double cellLat(int iy) => -90 + (iy + 0.5) * 2;
double cellLon(int ix) => -180 + (ix + 0.5) * 2;

/// Anonymous world heat: coarse cells only. Shows demo data when no server is set.
class Presence {
  final heat = ValueNotifier<List<HeatCell>>(const []);
  final total = ValueNotifier<int>(0);
  bool demo = false;
  WebSocketChannel? _ws;
  Timer? _mock;
  bool _closed = false;

  Future<void> start() async {
    final url = Config.serverUrl.trim();
    if (url.isEmpty) {
      demo = true;
      _tickMock();
      _mock = Timer.periodic(const Duration(seconds: 3), (_) => _tickMock());
      return;
    }
    try {
      var u = url;
      if (u.startsWith('https://')) {
        u = 'wss://${u.substring(8)}';
      } else if (u.startsWith('http://')) {
        u = 'ws://${u.substring(7)}';
      } else if (!u.startsWith('ws')) {
        u = 'wss://$u';
      }
      final ws = _ws = WebSocketChannel.connect(Uri.parse(u));
      await ws.ready.timeout(const Duration(seconds: 70));
      ws.stream.listen((raw) async {
        try {
          final m = jsonDecode(raw as String) as Map;
          switch (m['t']) {
            case 'hello':
              {
                final s = await Identity.authFields(m['nonce'] as String, (m['pow'] as num?)?.toInt() ?? 0);
                ws.sink.add(jsonEncode({'t': 'auth', ...s}));
                break;
              }
            case 'ready':
              if (m['token'] is String) await Identity.saveToken(m['token'] as String);
              ws.sink.add(jsonEncode({'t': 'watch', 'on': true}));
              break;
            case 'heat':
              if (_closed) return;
              heat.value = (m['cells'] as List).map((c) => HeatCell(c[0] as int, c[1] as int, c[2] as int, c[3] as int)).toList();
              total.value = (m['total'] as num?)?.toInt() ?? 0;
              break;
          }
        } catch (_) {}
      }, onError: (_) {}, onDone: () {});
    } catch (_) {}
  }

  static const _spots = <List<double>>[
    [40.7, -74, 9], [51.5, -0.1, 8], [6.5, 3.4, 11], [30, 31.2, 7], [-1.3, 36.8, 6], [19, 72.9, 9], [28.6, 77.2, 8],
    [23.8, 90.4, 6], [-6.2, 106.8, 7], [14.6, 121, 6], [35.7, 139.7, 8], [37.5, 127, 6], [31.2, 121.5, 7], [39.9, 116.4, 6],
    [-33.9, 151.2, 5], [-23.5, -46.6, 9], [-34.6, -58.4, 6], [19.4, -99.1, 8], [34, -118.2, 7], [41.9, -87.6, 6],
    [43.7, -79.4, 5], [48.9, 2.35, 7], [52.5, 13.4, 5], [40.4, -3.7, 5], [41, 29, 7], [55.7, 37.6, 5], [25.2, 55.3, 6],
    [-26.2, 28, 6], [5.6, -0.2, 7], [4.7, -74.1, 6], [-12, -77, 5], [24.9, 67, 6], [13.8, 100.5, 6], [-33.9, 18.4, 4],
    [33.6, -7.6, 4], [9, 38.7, 5], [-4.3, 15.3, 5], [-33.4, -70.6, 4],
  ];

  void _tickMock() {
    if (_closed) return;
    final t = DateTime.now().millisecondsSinceEpoch / 1000.0;
    final map = <int, List<int>>{};
    var sum = 0;
    for (var i = 0; i < _spots.length; i++) {
      final s = _spots[i];
      final ix = ((s[1] + 180) / 2).floor(), iy = ((s[0] + 90) / 2).floor();
      final l = (s[2] * (0.5 + 0.5 * sin(t * 0.18 + i))).round();
      final w = (s[2] * 0.6 * (0.5 + 0.5 * sin(t * 0.13 + i * 1.7))).round();
      final e = map.putIfAbsent(iy * 1000 + ix, () => [ix, iy, 0, 0]);
      e[2] += l;
      e[3] += w;
      sum += l + w;
    }
    heat.value = map.values.map((e) => HeatCell(e[0], e[1], e[2], e[3])).toList();
    total.value = sum;
  }

  void dispose() {
    _closed = true;
    _mock?.cancel();
    try {
      _ws?.sink.close();
    } catch (_) {}
  }
}

/// 360x180 glow map (1 degree per pixel): red = listening, green = whispering.
Future<ui.Image> buildHeatImage(List<HeatCell> cells) {
  const w = 360, h = 180;
  final r = Float32List(w * h), g = Float32List(w * h);
  for (final c in cells) {
    final cx = (c.ix * 2 + 1).toDouble(), cy = (180 - (c.iy * 2 + 1)).toDouble();
    final li = min(1.0, c.listen / 10.0), ti = min(1.0, c.talk / 6.0);
    for (var dy = -7; dy <= 7; dy++) {
      final y = (cy + dy).round();
      if (y < 0 || y >= h) continue;
      for (var dx = -7; dx <= 7; dx++) {
        final x = (cx + dx).round() % w;
        final k = exp(-(dx * dx + dy * dy) / (2 * 2.4 * 2.4));
        r[y * w + x] += (li * k).toDouble();
        g[y * w + x] += (ti * k).toDouble();
      }
    }
  }
  final px = Uint8List(w * h * 4);
  for (var i = 0; i < w * h; i++) {
    px[i * 4] = (min(1.0, r[i]) * 255).round();
    px[i * 4 + 1] = (min(1.0, g[i]) * 255).round();
    px[i * 4 + 3] = 255;
  }
  final c = Completer<ui.Image>();
  ui.decodeImageFromPixels(px, w, h, ui.PixelFormat.rgba8888, c.complete);
  return c.future;
}
