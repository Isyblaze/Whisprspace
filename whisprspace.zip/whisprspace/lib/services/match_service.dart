import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

enum Scope { global, nearby }

enum Mood {
  calm('Calm', Color(0xFF5FB3FF)),
  lonely('Lonely', Color(0xFF9B8CFF)),
  hyped('Hyped', Color(0xFFFF8A5C)),
  curious('Curious', Color(0xFF4CD6B0)),
  restless('Restless', Color(0xFFFF6B9A)),
  reflective('Reflective', Color(0xFFD0B3FF));

  final String label;
  final Color color;
  const Mood(this.label, this.color);
}

class Match {
  final Mood? mood;
  final Scope scope;
  final CallSession? session;
  const Match(this.mood, this.scope, {this.session});
}

abstract class CallSession {
  void setMuted(bool m);
  void setSpeaker(bool on);
  Stream<void> get onEnded;
  Future<void> close();
}

class MatchError implements Exception {
  final String message;
  MatchError(this.message);
}

/// Swap this for a WebSocket matcher + WebRTC in Phase 1b.
abstract class MatchService {
  Future<Match?> find(Mood? mood, Scope scope);
  void cancel();
}

class AppSettings {
  static final voiceMask = ValueNotifier<bool>(false);
}

class MockMatchService implements MatchService {
  Timer? _t;
  Completer<Match?>? _c;

  @override
  Future<Match?> find(Mood? mood, Scope scope) {
    final c = _c = Completer<Match?>();
    _t = Timer(Duration(seconds: 2 + Random().nextInt(3)), () {
      if (!c.isCompleted) {
        c.complete(Match(mood ?? Mood.values[Random().nextInt(Mood.values.length)], scope));
      }
    });
    return c.future;
  }

  @override
  void cancel() {
    _t?.cancel();
    if (_c != null && !_c!.isCompleted) _c!.complete(null);
  }
}
