import 'package:geolocator/geolocator.dart';
import 'match_service.dart';

/// Returns a coarse grid cell (~11 km). Exact coordinates never leave the device.
Future<String> coarseCell() async {
  if (!await Geolocator.isLocationServiceEnabled()) {
    throw MatchError('Turn on location to whisper nearby.');
  }
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied || p == LocationPermission.deniedForever) {
    throw MatchError('Location permission is needed for Nearby.');
  }
  final pos = await Geolocator.getCurrentPosition(
    locationSettings: const LocationSettings(accuracy: LocationAccuracy.low),
  ).timeout(const Duration(seconds: 15), onTimeout: () => throw MatchError('Could not get a rough location.'));
  const step = 0.1;
  return '${(pos.latitude / step).floor()}:${(pos.longitude / step).floor()}';
}
