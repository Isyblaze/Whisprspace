import 'package:geolocator/geolocator.dart';

/// Rough home cell: 2 x 2 degrees (~220 km). Exact coordinates never leave the phone.
/// Returns null if location is off or not allowed.
Future<String?> homeCell() async {
  try {
    if (!await Geolocator.isLocationServiceEnabled()) return null;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.denied || p == LocationPermission.deniedForever) return null;
    final pos = await Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(accuracy: LocationAccuracy.low),
    ).timeout(const Duration(seconds: 12));
    final ix = ((pos.longitude + 180) / 2).floor().clamp(0, 179).toInt();
    final iy = ((pos.latitude + 90) / 2).floor().clamp(0, 89).toInt();
    return '$ix:$iy';
  } catch (_) {
    return null;
  }
}
