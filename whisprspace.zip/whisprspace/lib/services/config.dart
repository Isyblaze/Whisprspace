import 'package:shared_preferences/shared_preferences.dart';

const _def = String.fromEnvironment('WS_URL');

class Config {
  static String serverUrl = _def;

  static Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      serverUrl = p.getString('server') ?? _def;
    } catch (_) {}
  }

  static Future<void> save(String v) async {
    serverUrl = v.trim();
    try {
      (await SharedPreferences.getInstance()).setString('server', serverUrl);
    } catch (_) {}
  }
}
