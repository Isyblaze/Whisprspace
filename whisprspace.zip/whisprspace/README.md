# WhisprSpace
Anonymous, voice-first, ephemeral. No accounts, no profiles, no history.

![logo](assets/wordmark.png)

**Phase 1 (this build):** UI + mock matcher. No audio leaves the device.
Replace `MockMatchService` (lib/services/match_service.dart) with a WebSocket matcher + WebRTC.

## Build
Push to `main` -> GitHub Actions -> Actions tab -> `whisprspace-apk` artifact.

## Ambient background
`node tools/render_bg.js assets/bg_loop.mp4` regenerates the 20s seamless loop (silhouettes in the void) (needs node + ffmpeg).

## The Void (Phase 4)
Home orb -> Void: a GPU-rendered 3D Earth (shaders/globe.frag) with anonymous heat by 2-degree region
(only shown once >= HEAT_MIN people are active). Region search needs both people to fit each other's area.
Earth imagery: NASA Earth Observatory, Blue Marble Next Generation (public domain); downloaded during the build.
