# WhisprSpace
Anonymous, voice-first, ephemeral. No accounts, no profiles, no history.

![logo](assets/wordmark.png)

**Phase 1 (this build):** UI + mock matcher. No audio leaves the device.
Replace `MockMatchService` (lib/services/match_service.dart) with a WebSocket matcher + WebRTC.

## Build
Push to `main` -> GitHub Actions -> Actions tab -> `whisprspace-apk` artifact.

## Ambient background
`node tools/render_bg.js assets/bg_loop.mp4` regenerates the 20s seamless loop (silhouettes in the void) (needs node + ffmpeg).
