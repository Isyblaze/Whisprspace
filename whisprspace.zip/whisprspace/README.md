# WhisprSpace
Anonymous, voice-first, ephemeral. No accounts, no profiles, no history.

![logo](assets/wordmark.png)

**Phase 1 (this build):** UI + mock matcher. No audio leaves the device.
Replace `MockMatchService` (lib/services/match_service.dart) with a WebSocket matcher + WebRTC.

## Build
Push to `main` -> GitHub Actions -> Actions tab -> `whisprspace-apk` artifact.
