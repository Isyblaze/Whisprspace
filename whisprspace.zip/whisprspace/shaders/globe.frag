#version 460 core
#include <flutter/runtime_effect.glsl>

uniform vec2 uSize;
uniform float uLon;
uniform float uLat;
uniform float uRadius;
uniform float uTime;
uniform float uSelLat;
uniform float uSelLon;
uniform float uSelR;
uniform float uHeatGain;
uniform float uSearch;
uniform sampler2D uDay;
uniform sampler2D uHeat;

out vec4 fragColor;

const float PI = 3.14159265359;

float hash(vec3 p) {
  p = fract(p * 0.3183099 + vec3(0.1, 0.2, 0.3));
  p *= 17.0;
  return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

float noise(vec3 x) {
  vec3 i = floor(x);
  vec3 f = fract(x);
  f = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(mix(hash(i + vec3(0.0, 0.0, 0.0)), hash(i + vec3(1.0, 0.0, 0.0)), f.x),
        mix(hash(i + vec3(0.0, 1.0, 0.0)), hash(i + vec3(1.0, 1.0, 0.0)), f.x), f.y),
    mix(mix(hash(i + vec3(0.0, 0.0, 1.0)), hash(i + vec3(1.0, 0.0, 1.0)), f.x),
        mix(hash(i + vec3(0.0, 1.0, 1.0)), hash(i + vec3(1.0, 1.0, 1.0)), f.x), f.y),
    f.z);
}

float fbm(vec3 p) {
  float a = 0.5;
  float s = 0.0;
  for (int i = 0; i < 4; i++) {
    s += a * noise(p);
    p *= 2.03;
    a *= 0.5;
  }
  return s;
}

void main() {
  vec2 frag = FlutterFragCoord().xy;
  vec2 d = (frag - uSize * 0.5) / uRadius;
  d.y = -d.y;
  float r2 = dot(d, d);
  float r = sqrt(r2);

  float cl = cos(uLat);
  float sl = sin(uLat);
  float co = cos(uLon);
  float so = sin(uLon);
  vec3 ce = vec3(co, 0.0, -so);
  vec3 cn = vec3(-sl * so, cl, -sl * co);
  vec3 cz = vec3(cl * so, sl, cl * co);

  vec3 sun = normalize(vec3(-0.55, 0.35, 0.75));

  if (r < 1.0) {
    float z = sqrt(1.0 - r2);
    vec3 n = vec3(d, z);
    vec3 w = d.x * ce + d.y * cn + z * cz;
    float lat = asin(clamp(w.y, -1.0, 1.0));
    float lon = atan(w.x, w.z);
    vec2 uv = vec2(lon / (2.0 * PI) + 0.5, 0.5 - lat / PI);

    vec3 tex = texture(uDay, uv).rgb;
    float lum = dot(tex, vec3(0.299, 0.587, 0.114));
    vec3 col = mix(vec3(lum), tex, 1.12);

    float diff = dot(n, sun);
    float lit = smoothstep(-0.18, 0.55, diff);
    float shade = mix(0.30, 1.05, lit);

    float ocean = smoothstep(0.0, 0.10, tex.b - max(tex.r, tex.g));
    float spec = pow(max(dot(reflect(-sun, n), vec3(0.0, 0.0, 1.0)), 0.0), 32.0) * ocean;

    float cld = fbm(w * 3.2 + vec3(uTime * 0.004, 0.0, 0.0));
    cld = smoothstep(0.55, 0.80, cld) * 0.55;
    col = mix(col, vec3(1.0), cld);

    col = col * shade + vec3(0.8, 0.85, 1.0) * spec * 0.35 * lit;
    float fres = pow(1.0 - z, 3.0);
    col += vec3(0.28, 0.38, 1.0) * fres * 0.55 * (0.35 + 0.65 * lit);

    vec2 hv = texture(uHeat, uv).rg;
    float pulse = 0.78 + 0.22 * sin(uTime * 2.2 + uv.x * 40.0);
    float pulse2 = 0.82 + 0.18 * sin(uTime * 3.0 + uv.y * 30.0);
    vec3 heat = vec3(0.60, 0.40, 1.0) * hv.r * pulse + vec3(1.0, 0.50, 0.78) * hv.g * pulse2;
    col += heat * uHeatGain * 1.25;

    vec3 selDir = vec3(cos(uSelLat) * sin(uSelLon), sin(uSelLat), cos(uSelLat) * cos(uSelLon));
    if (uSelR > 0.0) {
      float ang = acos(clamp(dot(w, selDir), -1.0, 1.0));
      float inside = smoothstep(uSelR, uSelR * 0.97, ang);
      float rq = (ang - uSelR) / 0.012;
      float ring = exp(-rq * rq);
      col = mix(col, col * 0.75 + vec3(0.40, 0.28, 0.95) * 0.40, inside * 0.65);
      col += vec3(0.75, 0.65, 1.0) * ring * (0.85 + 0.15 * sin(uTime * 3.0));
    }
    if (uSearch > 0.5) {
      vec3 o = cz;
      float maxAng = 2.4;
      if (uSelR > 0.0) {
        o = selDir;
        maxAng = uSelR * 1.7;
      }
      float ang2 = acos(clamp(dot(w, o), -1.0, 1.0));
      float ph = fract(uTime * 0.45);
      float wq = (ang2 - ph * maxAng) / 0.035;
      float wave = exp(-wq * wq) * (1.0 - ph);
      col += vec3(0.70, 0.55, 1.0) * wave * 0.9;
    }

    float edge = smoothstep(1.0, 0.994, r);
    fragColor = vec4(col * edge, edge);
  } else {
    float h = exp(-(r - 1.0) * 9.0) * 0.85;
    vec2 dir = d / max(r, 0.0001);
    float side = smoothstep(-0.6, 0.6, dot(dir, normalize(vec2(-0.55, 0.35))));
    vec3 halo = mix(vec3(0.20, 0.28, 0.95), vec3(0.45, 0.30, 0.95), 0.4) * h * (0.30 + 0.70 * side);
    float a = clamp(h * (0.30 + 0.70 * side), 0.0, 1.0);
    fragColor = vec4(halo, a);
  }
}
