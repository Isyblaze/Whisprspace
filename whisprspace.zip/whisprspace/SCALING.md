# WhisprSpace: scaling and bot protection runbook

## What protects against bots (built)
- Random on-device key = anonymous identity; every connection proves it with a signature.
- Proof-of-work for new devices (POW_BITS, default 16): ~0.2s for a phone, costly at bot scale. 12+ new devices/hour from one
  network address raises it by 4 bits; 40+ is refused. Returning devices skip it with a 12h signed session token.
- New devices search at 5/min (trusted: 10/min) and their reports count half. Trust grows from clean 60s+ calls.
- Real client address is taken from the proxy header (TRUST_PROXY_HOPS, default 1), not what the client claims.
- Not built: Google Play Integrity (needs a Google Cloud project + Play Console, see below).

## Scaling (built)
- One instance handles thousands: 5,000 simultaneous searches processed in ~0.3 s, 20,000 in ~5.6 s worst case
  (offline benchmark, excludes network). Audio never touches the server.
- /health shows online, waiting and calls (counts only). Servers say "restart" before a deploy and apps reconnect.
- MAX_CONNECTIONS (default 8000) returns "busy" instead of falling over. Search widens: mood after 15s, region radius after 30s.
- REDIS_URL (optional) keeps bans, strikes, blocks and trust across restarts. Without it they live in memory.
- Cloudflare TURN (CF_TURN_KEY_ID + CF_TURN_API_TOKEN) hands out 4-hour credentials, refreshed every 30 minutes.

## Env vars
AUTH_SECRET (set it! keeps sessions valid across restarts), POW_BITS, REDIS_URL, CF_TURN_KEY_ID, CF_TURN_API_TOKEN,
HEAT_MIN, MAX_CONNECTIONS, MAX_CONN_PER_IP, TRUST_PROXY_HOPS.

## Beyond one instance (not built)
Several instances need a shared matching queue and cross-instance signaling (Redis pub/sub). One paid always-on instance
comfortably covers the first tens of thousands of users; do this later.

## Play Integrity (next, needs Google setup)
Create a Google Cloud project, link it in Play Console, publish to an internal test track, add the Play Integrity
client in the app, and verify the token on the server. Until then the proof-of-work + trust system is the bot defence.
